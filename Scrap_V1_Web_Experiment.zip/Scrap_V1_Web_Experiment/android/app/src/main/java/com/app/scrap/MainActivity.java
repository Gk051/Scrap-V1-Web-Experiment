package com.app.scrap;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
