# Flutter
-keep class io.flutter.** { *; }
-dontwarn io.flutter.embedding.**

# Prevent stripping from main activity
-keep class com.app.scrap.** { *; }

# Keep Firebase, Retrofit, or other critical libraries if used
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**

# Don't warn about missing error-prone annotations
-dontwarn com.google.errorprone.annotations.**

# Don't warn about missing javax annotations
-dontwarn javax.annotation.**
-dontwarn javax.annotation.concurrent.**

# Prevent removal of any crypto/Tink-related classes
-keep class com.google.crypto.tink.** { *; }

# Prevent stripping of all annotations
-keepattributes *Annotation*

-dontwarn com.google.api.client.http.GenericUrl
-dontwarn com.google.api.client.http.HttpHeaders
-dontwarn com.google.api.client.http.HttpRequest
-dontwarn com.google.api.client.http.HttpRequestFactory
-dontwarn com.google.api.client.http.HttpResponse
-dontwarn com.google.api.client.http.HttpTransport
-dontwarn com.google.api.client.http.javanet.NetHttpTransport$Builder
-dontwarn com.google.api.client.http.javanet.NetHttpTransport
-dontwarn org.joda.time.Instant
