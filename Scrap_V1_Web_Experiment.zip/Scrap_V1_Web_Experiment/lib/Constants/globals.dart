class ApiUrls {
  // WEB EXPERIMENT: the API address can now be set when the web app is built:
  //   flutter build web --dart-define=API_BASE_URL=https://your-api-host/
  // If nothing is supplied it falls back to the host the original app used,
  // but over https (a web page served over https cannot call plain http).
  // The value must point at the same API paths the app already uses
  // (e.g. <base>/api/login/). A trailing slash is added automatically.
  static const String _configuredBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://sachitbsha.pythonanywhere.com/',
  );
  static final String baseUrl =
      _configuredBaseUrl.endsWith('/') ? _configuredBaseUrl : '$_configuredBaseUrl/';

  // Original (untouched) values from the mobile project, kept for reference:
  // static const String baseUrl = "http://sachitbsha.pythonanywhere.com/";
  // static const String baseUrl = "http://sachituk.pythonanywhere.com/";
  // static const String baseUrl = "http://Udhay.pythonanywhere.com/";
}
