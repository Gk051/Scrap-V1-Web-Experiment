import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

import '../Services/LoaderService.dart';


class GlobalLoader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final isLoading = context.watch<LoaderProvider>().isLoading;

    return isLoading
        ? Container(
      color: Colors.black.withOpacity(0.5), // Semi-transparent background
      child: Center(
        child: SpinKitFadingCircle(
          color: Colors.white, // Spinner color
          size: 50.0,          // Spinner size
        ),
      ),
    )
        : SizedBox.shrink(); // Hidden when not loading
  }
}
