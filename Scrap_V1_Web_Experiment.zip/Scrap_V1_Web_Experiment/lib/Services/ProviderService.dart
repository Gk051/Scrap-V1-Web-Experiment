import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
class MainProvider with ChangeNotifier {

  // user detail

  int user_id = 0;
  void updateUserId({required int id}){
    user_id = id;
    notifyListeners();
  }

  Map userData = {};

  void updateUserData({required Map data}){
    userData = data;
    notifyListeners();
  }

  //products
  Map<dynamic,dynamic> selectedProduct = {};

  void updateSelectedProduct({required Map<dynamic , dynamic> data}){
    selectedProduct = data;
    notifyListeners();
  }

  //date and time
  DateTime selectedDate = DateTime.now().hour >= 15 ? DateTime.now().add(Duration(days: 1)) : DateTime.now();

  void updateDateTime({required DateTime selectionDate}){
    selectedDate = selectionDate;
    notifyListeners();
  }

  //address
  int selectedAddressindex = 0;

  List<dynamic> Address = [];

  void updateAddressIndex({required int index}) {
    selectedAddressindex = index;
    notifyListeners(); // Notify listeners to rebuild the UI
  }

  void updateAddress({required List<dynamic> address}){
    Address = address;
    notifyListeners();
  }

  String Payment_Type = 'Cash On Pickup';
  String Upi = 'none';
  bool isCash = true;
  void updatePayment(String payment){
    Payment_Type = payment;
    notifyListeners();
  }

  void updateCashStatus(bool val){
    isCash = val;
    notifyListeners();
  }

  void updateUpiStatus(String val){
    Upi = val;
    notifyListeners();
  }

  int quantity = 1;

  void incrementQuantity(){
    WidgetsBinding.instance.addPostFrameCallback((_) {
      quantity += 1;
      notifyListeners();
    });
  }

  void decrementQuantity(){
    WidgetsBinding.instance.addPostFrameCallback((_) {
      quantity -= 1;
      notifyListeners();
    });
  }

  List rateList = [];

  void updateRateList({required List data}){
    rateList = data;
    notifyListeners();
  }

  List<dynamic> Requests = [];

  void updateRequests({required List<dynamic> data}){
    Requests = data;
    notifyListeners();
  }

  void appendRequests({required Map<dynamic,dynamic> data}){
    Requests.add(data);
    notifyListeners();
  }

  void Load(){
    Requests = Requests;
    notifyListeners();
  }
}
