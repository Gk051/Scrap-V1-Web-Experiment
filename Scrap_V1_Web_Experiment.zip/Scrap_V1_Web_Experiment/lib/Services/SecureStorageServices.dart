import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

// WEB EXPERIMENT: every call is now failure-tolerant. A broken, corrupted or
// unavailable store (private browsing, blocked storage, restored Android backup
// without its keys) is treated as "nothing saved" instead of throwing, which
// used to leave the launch screen spinning forever.
class SecureStorage {
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  // Save data securely
  Future<void> saveData(String key, String value) async {
    try {
      await _storage.write(key: key, value: value);
    } catch (e) {
      debugPrint('SecureStorage.saveData failed: $e');
    }
  }

  // Retrieve data securely (returns null if missing or unreadable)
  Future<String?> getData(String key) async {
    try {
      return await _storage.read(key: key);
    } catch (e) {
      debugPrint('SecureStorage.getData failed: $e');
      try {
        await _storage.delete(key: key);
      } catch (_) {}
      return null;
    }
  }

  // Delete data securely
  Future<void> deleteData(String key) async {
    try {
      await _storage.delete(key: key);
    } catch (e) {
      debugPrint('SecureStorage.deleteData failed: $e');
    }
  }
}
