import 'package:flutter/material.dart';

class LoaderProvider with ChangeNotifier {
  bool _isLoading = false;

  bool get isLoading => _isLoading;

  void showLoader() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _isLoading = true;
      notifyListeners();
    });
  }

  void hideLoader() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _isLoading = false;
      notifyListeners();
    });
  }

  bool _isRateListLoading = false;

  bool get isRateListLoading => _isRateListLoading;

  void showRateListLoader() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _isRateListLoading = true;
      notifyListeners();
    });
  }

  void hideRateListLoader() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _isRateListLoading = false;
      notifyListeners();
    });
  }
}
