import 'package:scrap_app_v2/Services/http_with_timeout.dart' as http;
import 'dart:convert';

import 'package:scrap_app_v2/Constants/globals.dart';
class Authenticateservice{
  bool _isMobileNumber(String input) {
    final mobileRegex = RegExp(r'^\d{10}$');
    return mobileRegex.hasMatch(input);
  }
  Future<dynamic> Login({required String Username , required String Password})async {

      final response = await http.post(
        Uri.parse(ApiUrls.baseUrl+'api/login/'),
        headers: {"Content-Type": "application/json"},
        body: _isMobileNumber(Username)?json.encode({
          'mobile': Username,
          'password': Password,
        }):json.encode({
          'username': Username,
          'password': Password,
        }),
      );
      return response;
  }

  Future<dynamic> SignUp({required String Username , required String Password , required String Mobile})async {
    final response = await http.post(
      Uri.parse(ApiUrls.baseUrl+'api/register/'),
      headers: {"Content-Type": "application/json"},
      body: json.encode({
        'user_name': Username,
        'email': Username,
        'password': Password,
        'mobile_number':Mobile
      }),
    );
    return response;
  }

  Future<dynamic> ResetPassword({required String Username , required String Email})async {
    // WEB EXPERIMENT: network errors / timeouts now return false (the screen
    // already shows "Failed to send OTP" for false) instead of throwing.
    try {
      final response = await http.post(
        Uri.parse(ApiUrls.baseUrl+'api/forgot-password'),
        headers: {"Content-Type": "application/json"},
        body: json.encode({
          'user_name': Username,
          'email': Email,
        }),
      );
      return response.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  Future<dynamic> VerifyOTP({required String Otp , required String Password})async {
    // WEB EXPERIMENT: same failure-tolerance as ResetPassword.
    try {
      final response = await http.post(
        Uri.parse(ApiUrls.baseUrl+'api/reset-password'),
        headers: {"Content-Type": "application/json"},
        body: json.encode({
          'otp': Otp,
          'new_password': Password,
        }),
      );
      return response.statusCode == 200;
    } catch (_) {
      return false;
    }
  }


}