import 'package:flutter/cupertino.dart';
import 'package:scrap_app_v2/Services/http_with_timeout.dart' as http;
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'dart:convert';

import 'package:scrap_app_v2/Constants/globals.dart';
import 'package:scrap_app_v2/Services/ProviderService.dart';

class Dataservice{
  Future<dynamic> GetCategory()async {
    final response = await http.get(
      Uri.parse(ApiUrls.baseUrl+'api/get_categories/'),
      headers: {"Content-Type": "application/json"}
    );
    print("category :" + response.body);
    return jsonDecode(response.body);
  }

  Future<dynamic> GetProducts({required int id})async {
    print(Uri.parse(ApiUrls.baseUrl+'api/fetch_products_for_category/?category_id=${id}'));
    final response = await http.get(
        Uri.parse(ApiUrls.baseUrl+'api/fetch_products_for_category/?category_id=${id}'),
        headers: {"Content-Type": "application/json"}
    );
    // WEB EXPERIMENT: errors (e.g. an HTML page instead of JSON) are no longer
    // swallowed into a null result; the calling screen shows a retry message.
    return jsonDecode(response.body);
  }

  Future<dynamic> GetProfileDetails({required int id})async {
    final response = await http.post(
        Uri.parse(ApiUrls.baseUrl+'api/fetch_profile_details/'),
        headers: {"Content-Type": "application/json"} , body: json.encode({"user_id":id})
    );
    print(response.body);
    return jsonDecode(response.body);
  }

  Future<dynamic> UpdateMobile({ required BuildContext context , required String mobile})async {
    try {
      final response = await http.post(
          Uri.parse(ApiUrls.baseUrl + 'api/update_profile/'),
          headers: {"Content-Type": "application/json"}, body: json.encode({
        "user_id": context.read<MainProvider>().user_id,
        "mobile": int.parse(mobile)
      })
      );
      print(response.body);
      return {"statusCode":response.statusCode};
    }catch(e){
      return {"statusCode":500};
    }
  }

  Future<dynamic> UpdateName({ required BuildContext context , required String name})async {
    try {
      final response = await http.post(
          Uri.parse(ApiUrls.baseUrl + 'api/update_profile/'),
          headers: {"Content-Type": "application/json"}, body: json.encode({
        "user_id": context.read<MainProvider>().user_id,
        "username": name
      })
      );
      print(response.body);
      return {"statusCode":response.statusCode};
    }catch(e){
      return {"statusCode":500};
    }
  }


  Future<dynamic> AddAddress({ required BuildContext context , required int id , required String type , required String address})async {
    try {
      final response = await http.post(
          Uri.parse(ApiUrls.baseUrl + 'api/add_new_address/'),
          headers: {"Content-Type": "application/json"}, body: json.encode({
        "address": address,
        "type": type,
        "user_id": id
      })
      );
      print(response.body);
      List<dynamic> data = context.read<MainProvider>().Address;
      data.add({"address": address,
        "type": type});
      context.read<MainProvider>().updateAddress(address: data);
      return true;
    }catch(e){
      return false;
    }
  }

  Future<dynamic> BookOrder({ required BuildContext context , required String instruction})async {
    try {
      print({
        "user_id": context.read<MainProvider>().user_id,
        "address_id":context.read<MainProvider>().Address[context.read<MainProvider>().selectedAddressindex]['address_id']??1,
        "ordered_at":DateTime.now().toString(),
        "items":[
          {
            "item_id":context.read<MainProvider>().selectedProduct['product_id'],
            "quantity":context.read<MainProvider>().quantity,
          }
        ],
        "pick_up_date":DateFormat('yyyy-MM-dd').format(context.read<MainProvider>().selectedDate).toString(),
        "instructions":instruction==""?"come fast":instruction,
        "money_acceptance_mode":context.read<MainProvider>().isCash?"COP":"UPI",
        "UPI_mobile_number":context.read<MainProvider>().Upi
      });
      final response = await http.post(
          Uri.parse(ApiUrls.baseUrl + 'api/book_order/'),
          headers: {"Content-Type": "application/json"}, body:
      json.encode({
        "user_id": context.read<MainProvider>().user_id,
        "address_id":context.read<MainProvider>().Address[context.read<MainProvider>().selectedAddressindex]['address_id']??1,
        "ordered_at":DateTime.now().toString(),
        "items":[
          {
            "item_id":context.read<MainProvider>().selectedProduct['product_id'],
            "quantity":context.read<MainProvider>().quantity,
          }
          ],
        "pick_up_date":DateFormat('yyyy-MM-dd').format(context.read<MainProvider>().selectedDate).toString(),
        "instructions":instruction==""?"come fast":instruction,
        "money_acceptance_mode":context.read<MainProvider>().isCash?"COP":"UPI",
        "UPI_mobile_number":context.read<MainProvider>().Upi
      })
      );
      print(response.body);
      Map data = jsonDecode(response.body);

      return {...data , "statusCode":response.statusCode};
    }catch(e){
      print(e.toString());
      return {"statusCode":500 , "message":e.toString()};
    }
  }

  Future<dynamic> GetOrderDetails({required String id})async {
    final response = await http.post(
        Uri.parse(ApiUrls.baseUrl+'api/fetch_order_details/'),
        headers: {"Content-Type": "application/json"} , body: json.encode({"order_id":id})
    );
    print(response.body);
    Map data = jsonDecode(response.body);
    data.containsKey('status')?data['order_status']=data['status']:data['order_status']=data['order_status'];
    return data;
  }

  Future<dynamic> CancelOrder({required String id , required String reason})async {
    final response = await http.post(
        Uri.parse(ApiUrls.baseUrl+'api/cancel_order/'),
        headers: {"Content-Type": "application/json"} , body: json.encode({"order_id":id , "reason":reason})
    );
    print(response.body);
    return response;
  }

  Future<dynamic> GetAllOrderDetails({required int id})async {
    // WEB EXPERIMENT: errors are no longer turned into an empty list, so the
    // requests screen can tell "no requests" apart from "could not load".
    final response = await http.post(
        Uri.parse(ApiUrls.baseUrl + 'api/get_order_details_for_user/'),
        headers: {"Content-Type": "application/json"},
        body: json.encode({"user_id": id})
    );
    return jsonDecode(response.body);
  }

  Future<dynamic> FetchRateList({ required BuildContext context})async {
    try {
      final response = await http.get(
          Uri.parse(ApiUrls.baseUrl + 'api/fetch_rate_list/'),
          headers: {"Content-Type": "application/json"}
      );
      print(response.body);
      return {"statusCode":response.statusCode , "data":jsonDecode(response.body)};
    }catch(e){
      return {"statusCode":500};
    }
  }
}