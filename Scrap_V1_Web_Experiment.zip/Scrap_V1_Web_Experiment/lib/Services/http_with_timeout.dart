// WEB EXPERIMENT: drop-in replacement for `package:http/http.dart` used by the
// service layer. It exposes the same `get` / `post` signatures the app already
// uses, but every request now has a timeout so a slow or unreachable server can
// never leave the app waiting (and showing a spinner) forever.
//
// Endpoints, headers, request bodies and response handling are unchanged.
import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

export 'package:http/http.dart' show Response, ClientException;

/// How long we wait for the server before giving up.
const Duration kApiTimeout = Duration(seconds: 20);

Future<http.Response> get(Uri url, {Map<String, String>? headers}) {
  return http.get(url, headers: headers).timeout(kApiTimeout);
}

Future<http.Response> post(
  Uri url, {
  Map<String, String>? headers,
  Object? body,
  Encoding? encoding,
}) {
  return http
      .post(url, headers: headers, body: body, encoding: encoding)
      .timeout(kApiTimeout);
}

/// Turns any error thrown while calling the API into a short message that is
/// safe to show to a user (no stack traces, URLs or server internals).
String friendlyError(Object error) {
  if (error is TimeoutException) {
    return 'The server is taking too long to respond. '
        'Please check your connection and try again.';
  }
  if (error is FormatException) {
    return 'The server sent an unexpected response. '
        'Please try again in a little while.';
  }
  return 'We could not reach the server. '
      'Please check your internet connection and try again.';
}
