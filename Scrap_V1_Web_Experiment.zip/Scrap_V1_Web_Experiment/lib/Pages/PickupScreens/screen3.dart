

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/PickupConfirm.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/PickupDetails.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/pickAddress.dart';
import 'package:scrap_app_v2/Pages/Ratelist/RateList.dart';
import 'package:scrap_app_v2/Services/DataService.dart';
import 'package:scrap_app_v2/Services/ProviderService.dart';

import '../../Services/LoaderService.dart';
import 'PickMoneymode.dart';
import 'package:intl/intl.dart';
class RaiseScreen3 extends StatefulWidget {
  const RaiseScreen3({Key? key}) : super(key: key);

  @override
  State<RaiseScreen3> createState() => _RaiseScreen3State();
}

class _RaiseScreen3State extends State<RaiseScreen3> {
  int _currentIndex = 0;
  String desc = '';
  TextEditingController myController1 = TextEditingController();
  @override
  void initState() {
    print(context.read<MainProvider>().selectedProduct);
    super.initState();
  }
  void dispose() {
    // Clean up the controller when the widget is disposed.
    myController1.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: CustomAppBar(),
      body:  context.watch<LoaderProvider>().isLoading?Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SpinKitCircle(
              color: Color(0xff00685c), // Spinner color
              size: 50.0,          // Spinner size
            ),
            Text('Booking Order...' , style:GoogleFonts.poppins(color: Colors.black , fontSize: 18))
          ],
        ),
      ):[
        SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 125,),
              Padding(
                padding: const EdgeInsets.only(left:0.0 , top: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          width: 30,
                          height: 2,
                          decoration: BoxDecoration(
                              color: Color(0xffccebe8)
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Color(0xffccebe8)
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text('1 item picked' , style: GoogleFonts.poppins(fontSize: 11 , color: Color(0xff5f5f5f)),),
                          ),
                        ),
                        Container(
                          width: 30,
                          height: 2,
                          decoration: BoxDecoration(
                              color: Color(0xffccebe8)
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Color(0xffccebe8)
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text('Date Picked' , style: GoogleFonts.poppins(fontSize: 11 , color: Color(0xff5f5f5f)),),
                          ),
                        ),
                        Container(
                          width: 30,
                          height: 2,
                          decoration: BoxDecoration(
                              color: Color(0xffccebe8)
                          ),
                        ),
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Color(0xff00685c)
                          ),
                        )
                      ],
                    ),
                    Expanded(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [


                          Container(
                            decoration: BoxDecoration(
                               border: Border.all(color: Color(0xff00685c) , width: 1)
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Text('Confirm' , style: GoogleFonts.poppins(fontSize: 11 , color: Color(0xff5f5f5f)),),
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 25.0 , top: 20),
                child: Text('Confirm Your Pickup' , style: GoogleFonts.lexend(fontSize: 26 ,fontWeight: FontWeight.w600)),
              ),

              Padding(
                padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 10 ),
                child: Text('Scrap items' , style: GoogleFonts.poppins(fontSize: 16 , color: Color(0xff585858)),),
              ),

              Padding(
                  padding: const EdgeInsets.only(left: 8.0 , top: 10 , right: 8  ),
                  child: Column(
                    children:[
                      Card(
                        elevation:2,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 18.0 , right: 18 , top: 20 , bottom: 5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(context.watch<MainProvider>().selectedProduct['product_name']??'News Paper' , style: GoogleFonts.poppins(fontSize: 16 , fontWeight: FontWeight.w500),),
                                  Text(context.watch<MainProvider>().selectedProduct!={}?'${context.watch<MainProvider>().selectedProduct['price']}/${context.watch<MainProvider>().selectedProduct['measurement']}':'₹16/kg' , style: GoogleFonts.poppins(fontSize: 12 , color: Color(0xff373737) , fontWeight: FontWeight.w500),),
    Container(
    padding: EdgeInsets.all(0),
    decoration: BoxDecoration(
    borderRadius: BorderRadius.circular(8),
    ),
    child: Row(
    mainAxisSize: MainAxisSize.min,
    children: [
    // Decrement Button
    IconButton(
    onPressed: () {
    if (context.read<MainProvider>().quantity > 1) {

      context.read<MainProvider>().decrementQuantity();

    }
    },
    icon: Icon(Icons.remove, color: Colors.red),
    splashRadius: 5,
    ),

    // Quantity Display
    Container(
    width: 10,
    alignment: Alignment.center,
    child: Text(
    '${context.watch<MainProvider>().quantity}',
    style: GoogleFonts.poppins(fontSize: 15, fontWeight: FontWeight.w600),
    ),
    ),

    // Increment Button
    IconButton(
    onPressed: () {
    context.read<MainProvider>().incrementQuantity();
    },
    icon: Icon(Icons.add, color: Colors.green),
    splashRadius: 5,
    ),
    ],
    ),
    )
                                ],
                              ),
                              TextButton(onPressed: (){
                                Navigator.pop(context);
                                Navigator.pop(context);
                              }, child: Text('Change' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500 , color: Color(0xff00685c)),))
                            ],
                          ),
                        ),
                      ),
                      Card(
                        elevation:2,
                        child: Padding(
                          padding: const EdgeInsets.all(18.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Address' , style: GoogleFonts.poppins(fontSize: 15 ,color: Color(0xff8a8a8a), fontWeight: FontWeight.w500),),
                                  Container(
                                      width: 250,
                                      child: Text(context.watch<MainProvider>().Address[context.watch<MainProvider>().selectedAddressindex]['address'] , style: GoogleFonts.poppins(fontSize: 12 , color: Color(0xff373737) , fontWeight: FontWeight.w500),maxLines: 1,softWrap: true,overflow: TextOverflow.ellipsis,)),

                                ],
                              ),
                              TextButton(onPressed: (){
                                Navigator.push(context, MaterialPageRoute (
                                  builder: (BuildContext context) =>  PickAddress(),
                                ),);
                              }, child: Text('Change' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500 , color: Color(0xff00685c)),))
                            ],
                          ),
                        ),
                      ),
                      Card(
                        elevation:2,
                        child: Padding(
                          padding: const EdgeInsets.all(18.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Pickup' , style: GoogleFonts.poppins(fontSize: 15 ,color: Color(0xff8a8a8a), fontWeight: FontWeight.w500),),
                                  Text(DateFormat('EEEE , dd MMMM yyyy').format(context.watch<MainProvider>().selectedDate) , style: GoogleFonts.poppins(fontSize: 13 , color: Color(0xff373737) , fontWeight: FontWeight.w500),),
                                  Text('10 AM - 6 PM' , style: GoogleFonts.lexend(fontSize: 11 ,color: Color(0xff8a8a8a),),),

                                ],
                              ),
                              TextButton(onPressed: (){
                                Navigator.pop(context);
                              }, child: Text('Change' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500 , color: Color(0xff00685c)),))
                            ],
                          ),
                        ),
                      ),
                      Card(
                        elevation:2,
                        child: Padding(
                          padding: const EdgeInsets.all(18.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Payment acceptance Method' , style: GoogleFonts.poppins(fontSize: 14 ,color: Color(0xff8a8a8a), fontWeight: FontWeight.w500),),
                                  Text(context.watch<MainProvider>().Payment_Type , style: GoogleFonts.lexend(fontSize: 13  , fontWeight: FontWeight.w500),),

                                ],
                              ),
                              TextButton(onPressed: (

                                  ){
                                Navigator.push(context, MaterialPageRoute (
                                  builder: (BuildContext context) =>  PickMoneyMode(),
                                ),);
                              }, child: Text('Change' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500 , color: Color(0xff00685c)),))
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Any Instructions' , style: GoogleFonts.poppins(fontSize: 16 ,color: Color(0xff151111), fontWeight: FontWeight.w500),),
                            const SizedBox(height: 20,),
                            TextFormField(
                              maxLines: 3,
                              controller: myController1,
                              decoration:  InputDecoration(
                                // filled:true,
                                  helperText: 'EX : please call 5 mins before reaching..  ',
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: Color(0xffa8a8a8),
                                      width: 1.8,
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    // borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                      color: Color(0xff00685c),
                                      width: 1.4,
                                    ),
                                  ),
                                  labelStyle: TextStyle(
                                    color: Color(0xffa8a8a8),
                                    fontSize: 10

                                  ),

                                  hoverColor: Color(0xff00685c)
                              ),
                              keyboardType: TextInputType.text,
                              onFieldSubmitted: (value) {
                                setState(() {
                                  desc = value;
                                });
                              },
                              validator: (value) {
                                if (value!.isEmpty ) {
                                  return 'Invalid desc!';
                                }
                                return null;
                              },
                            ),
                             ],
                        ),
                      ),
                      SizedBox(height: 100,)
                    ]
                  )
              ),


            ],
          ),
        ),
        Ratelist()
      ][_currentIndex],
      floatingActionButton: _currentIndex==0?Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15),
        child: Container(
          width: MediaQuery.of(context).size.width,
          child: ElevatedButton(

            onPressed: () async{
              // Action to be performed on button press
              context.read<LoaderProvider>().showLoader();
              Map data = await Dataservice().BookOrder(context: context, instruction: myController1.text);
              print(data);
              print('999999999999999999');
              if(data['statusCode'] == 201 || data['statusCode'] == 200) {

                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                  builder: (BuildContext context) => PickupConfirm(OrderDetails: data,),
                ), (route) => false);
              }else{
                Fluttertoast.showToast(
                  msg: "Error Placing Order!",
                  toastLength: Toast.LENGTH_LONG,
                  gravity: ToastGravity.BOTTOM,
                  backgroundColor: Colors.black,
                  textColor: Colors.white,
                  fontSize: 16.0,
                );
                context.read<LoaderProvider>().hideLoader();
              }
            },

            style: ElevatedButton.styleFrom(
              disabledBackgroundColor: Color(0xff00685c).withOpacity(0.4),
              disabledForegroundColor: Colors.white,
              foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
              elevation: 5, // Elevation (shadow)
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(3.0), // Rounded corners
              ),
              padding: EdgeInsets.symmetric( vertical: 11), // Button padding
            ),
            child: Text('Book Order' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w600),), // Button text
          ),
        ),
      ):SizedBox(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        elevation: 0,
        type:BottomNavigationBarType.fixed,
        selectedItemColor: Color(0xff184d47),
        unselectedItemColor: Color(0xff184d47),
        selectedLabelStyle: GoogleFonts.poppins(fontWeight: FontWeight.w600),
        unselectedLabelStyle: GoogleFonts.poppins(),
        selectedFontSize: 18,
        unselectedFontSize: 18,
        items: [
          BottomNavigationBarItem(

            icon: _currentIndex == 0?Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: EdgeInsets.zero,
                  width: double.infinity,
                  height: 5,
                  color: Color(0xff184d47),
                ),
                SizedBox(height: 8,),
                Image.asset('assets/inithome/icon-bnavbar.png'),
              ],
            ):Image.asset('assets/inithome/icon-bnavbar.png'),
            label: 'Sell Scrap',
          ),
          BottomNavigationBarItem(
            icon: _currentIndex == 1?Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: EdgeInsets.zero,
                  width: double.infinity,
                  height: 5,
                  color: Color(0xff184d47),
                ),
                SizedBox(height: 8,),
                Image.asset('assets/inithome/icon-bnavbar2.png'),
              ],
            ):Image.asset('assets/inithome/icon-bnavbar2.png'),
            label: 'Rate List',
          ),

        ],
      ),
    );
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar-15 ,bottom: 10),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Sell Scrap' , style: GoogleFonts.lexend(fontSize: 18 , fontWeight: FontWeight.w500),),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Color(0xff00685C),
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30) , bottomRight: Radius.circular(30))
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}
