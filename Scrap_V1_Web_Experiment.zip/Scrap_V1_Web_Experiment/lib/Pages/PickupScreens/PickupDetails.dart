

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:scrap_app_v2/Components/Navbar.dart';
import 'package:scrap_app_v2/NavMenus/MenuActions/UpdateEmail.dart';
import 'package:scrap_app_v2/NavMenus/MenuActions/UpdateMobile.dart';
import 'package:scrap_app_v2/NavMenus/MenuActions/UpdateName.dart';
import 'package:scrap_app_v2/Pages/MainHome.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/AddAddress.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/pickAddress.dart';
import 'package:scrap_app_v2/Pages/Ratelist/MainRateList.dart';


class PickupDetails extends StatefulWidget {
  const PickupDetails({Key? key , required this.OrderDetails}) : super(key: key);
  final Map<dynamic , dynamic> OrderDetails;
  @override
  State<PickupDetails> createState() => _PickupDetailsState();
}

class _PickupDetailsState extends State<PickupDetails> {
  int _currentIndex = 0;
  String desc = '';
  TextEditingController myController1 = TextEditingController();
  void dispose() {
    // Clean up the controller when the widget is disposed.
    myController1.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: CustomAppBar(),
      drawer: Navbar(),
      body:
      SingleChildScrollView(
        child: Container(
          width: MediaQuery.of(context).size.width,
          child: Column(
            children: [
              SizedBox(height: 125,),

              Padding(
                padding: const EdgeInsets.all(20),
                child: Text('We are assigning your request to our pickup team' , style: GoogleFonts.lexend(fontSize: 16 , fontWeight: FontWeight.w500 , ),softWrap: true, textAlign: TextAlign.center,maxLines: 2,),
              ),
              Center(
                child: Image.asset('assets/inithome/call.png'),
              ),
              SizedBox(height: 20,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0 , vertical: 8),
                child: Row(
                  children: [
                    ProgressStep(
                      label: 'Request\nreceived',
                      isActive: true,
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 5.0),
                        child: Divider(
                          color: Color(0xff00685c), // Color for the active line
                          thickness: 3,
                        ),
                      ),
                    ),
                    ProgressStep(
                      label: 'Request\nassigned',
                      isActive: widget.OrderDetails['order_status']=='accepted' || widget.OrderDetails['order_status']=='picked'?true:false,
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 5.0),
                        child: Divider(
                          color: widget.OrderDetails['order_status']=='accepted' || widget.OrderDetails['order_status']=='picked'?Color(0xff00685c):Colors.grey, // Color for the inactive line
                          thickness: 3,
                        ),
                      ),
                    ),
                    ProgressStep(
                      label: 'Out for\npickup',
                      isActive: widget.OrderDetails['order_status']=='picked'?true:false,
                    ),
                  ],
                ),
              ),
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(0))
                ),
                child: ListTile(

                  leading: Icon(Icons.calendar_month_outlined , size: 30,color: Colors.black,),
                  // trailing: TextButton(onPressed: (){
                  //
                  // }, child: Text('Reschedule' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500 , color: Color(0xff00685c)),)),

                  title: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [

                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Expected Pickup' , style: GoogleFonts.poppins(fontSize: 15 ,color: Color(0xff8a8a8a), fontWeight: FontWeight.w500),),
                            Text(DateFormat('dd MMMM yyyy').format(DateTime.parse(widget.OrderDetails['pick_up_date'])) , style: GoogleFonts.poppins(fontSize: 14 , color: Color(0xff373737) , fontWeight: FontWeight.w500),),
                            Text('10 AM - 6 PM' , style: GoogleFonts.lexend(fontSize: 12 ,color: Color(0xff8a8a8a),),),

                          ],
                        ),

                      ],
                    ),
                  ),
                ),
              ),
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(0))
                ),
                child: ListTile(

                  leading: Icon(Icons.location_on , size: 30,color: Colors.black,),

                  title: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [

                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Address' , style: GoogleFonts.poppins(fontSize: 15 ,color: Color(0xff8a8a8a), fontWeight: FontWeight.w500),),
                              Text(widget.OrderDetails['address'] , style: GoogleFonts.poppins(fontSize: 13 , color: Color(0xff373737) , fontWeight: FontWeight.w500),overflow: TextOverflow.ellipsis,maxLines: 2,),
                          
                            ],
                          ),
                        ),

                      ],
                    ),
                  ),
                ),
              ),
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(0))
                ),
                child: ListTile(

                  leading: Icon(Icons.shopping_cart , size: 30,color: Colors.black,),

                  title: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [

                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Scrap items selected' , style: GoogleFonts.poppins(fontSize: 15 ,color: Color(0xff8a8a8a), fontWeight: FontWeight.w500),),
                              Text(widget.OrderDetails['items'][0]['item_name'][0].toUpperCase() + widget.OrderDetails['items'][0]['item_name'].substring(1) , style: GoogleFonts.poppins(fontSize: 13 , color: Color(0xff373737) , fontWeight: FontWeight.w500),overflow: TextOverflow.ellipsis,maxLines: 1,),

                            ],
                          ),
                        ),

                      ],
                    ),
                  ),
                ),
              ),
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(0))
                ),
                child: ListTile(
                  trailing: TextButton(onPressed: (){
                    Navigator. push(
                      context,
                      MaterialPageRoute(
                        builder: (BuildContext context) =>  Ratelist(),
                      ),
                    );
                  }, child: Text('Price list' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500 , color: Color(0xff00685c)),)),

                  title: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [

                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Scrap Pricing' , style: GoogleFonts.poppins(fontSize: 16 ,color: Color(0xff151111), fontWeight: FontWeight.w500),),

                          ],
                        ),

                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0 , vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Pickup instruction' , style: GoogleFonts.poppins(fontSize: 14 , fontWeight: FontWeight.w600),),
                    SizedBox(height: 5,),
                    Text('1. Please take out scrap items for faster pickup.' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500 , color: Color(0xff8a8a8a)),softWrap: true,),
                    SizedBox(height: 3,),
                    Text('2. Show pickup code to our executive.' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500 , color: Color(0xff8a8a8a)),softWrap: true,),
                    SizedBox(height: 3,),
                    Text('3. Prices are not negotiable. Check price list.' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500 , color: Color(0xff8a8a8a)),softWrap: true,),
                    SizedBox(height: 3,),
                    Text('4. Our prices are dynamic based on recycling industry.' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500 , color: Color(0xff8a8a8a)),softWrap: true,),

                  ],
                ),
              ),
              SizedBox(height: 100,),







            ],
          ),
        ),
      ),


    // floatingActionButton: Padding(
    //   padding: const EdgeInsets.symmetric(horizontal: 20),
    //   child: Container(
    //     width: MediaQuery.of(context).size.width,
    //     child: ElevatedButton(
    //
    //       onPressed: () {
    //         // Action to be performed on button press
    //         Navigator.push(context, MaterialPageRoute (
    //           builder: (BuildContext context) =>  MainHome(),
    //         ),);
    //       },
    //
    //       style: ElevatedButton.styleFrom(
    //         disabledBackgroundColor: Color(0xff00685c).withOpacity(0.4),
    //         disabledForegroundColor: Colors.white,
    //         foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
    //         elevation: 5, // Elevation (shadow)
    //         shape: RoundedRectangleBorder(
    //           borderRadius: BorderRadius.circular(3.0), // Rounded corners
    //         ),
    //         padding: EdgeInsets.symmetric( vertical: 11), // Button padding
    //       ),
    //       child: Text('Cancel order' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w600),), // Button text
    //     ),
    //   ),
    // ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar-15 ,bottom: 12),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Track Pickup details' , style: GoogleFonts.lexend(fontSize: 18 , fontWeight: FontWeight.w500),),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Color(0xff00685C),
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30) , bottomRight: Radius.circular(30))
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}


class ProgressStep extends StatelessWidget {
  final String label;
  final bool isActive;

  ProgressStep({required this.label, this.isActive = false});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          label,
          style: GoogleFonts.lexend(
            fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
            color: isActive ? Colors.black : Colors.grey,
            fontSize: 14
          ),

          softWrap: true,
        ),
        // Add spacing between text and line

      ],
    );
  }
}