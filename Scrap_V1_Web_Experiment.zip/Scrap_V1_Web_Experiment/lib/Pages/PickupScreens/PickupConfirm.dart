import 'package:flutter/material.dart';
import 'package:scrap_app_v2/Components/LoadingOrError.dart';
import 'package:scrap_app_v2/Services/http_with_timeout.dart' show friendlyError;
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/NavMenus/RequestStatus.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/PickupDetails.dart';
import 'package:scrap_app_v2/Pages/initialscreens/fourthscreen.dart';
import 'package:scrap_app_v2/Pages/initialscreens/secondscreen.dart';

import '../../Services/DataService.dart';
import '../../Services/LoaderService.dart';
import '../../Services/ProviderService.dart';
class PickupConfirm extends StatefulWidget {
  const PickupConfirm({Key? key , required this.OrderDetails}) : super(key: key);
  final Map OrderDetails;

  @override
  State<PickupConfirm> createState() => _PickupConfirmState();
}

class _PickupConfirmState extends State<PickupConfirm> {
  Map Itemdata = {};
  // WEB EXPERIMENT: if the order details cannot be loaded, say so (the order
  // itself has already been placed) and offer a retry instead of spinning forever.
  String? _loadError;

  dynamic getOrderDetails({required String id})async{
    final loader = context.read<LoaderProvider>();
    try {
      Itemdata = await Dataservice().GetOrderDetails(id: id);
      if (!mounted) return;
      context.read<MainProvider>().appendRequests(data: Itemdata);
      _loadError = null;
    } catch (e) {
      _loadError = 'Your order was placed, but we could not load its details. ' + friendlyError(e);
    }
    loader.hideLoader();
    if (!mounted) return;
    setState(() {

    });
  }

  void _reload() {
    setState(() {
      _loadError = null;
    });
    context.read<LoaderProvider>().showLoader();
    getOrderDetails(id: widget.OrderDetails['order_id']);
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getOrderDetails(id: widget.OrderDetails['order_id']);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:Colors.white,
      body: (context.watch<LoaderProvider>().isLoading || _loadError != null)?LoadingOrError(error: _loadError, onRetry: _reload):Padding(
        padding: const EdgeInsets.all(0.0),
        child: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 0.0 , left: 0),
                child: Column(
                  children: [
                    Container(
                      child: Lottie.asset('assets/inithome/pickup.json' ,
                      width: MediaQuery.of(context).size.width-20,
                      fit: BoxFit.fill,
                      repeat: true,
                        animate: true,
                        onLoaded: (composition) {
                                                   context.read<LoaderProvider>().hideLoader();
                          print('Animation loaded successfully${composition.layers}');
                        },
                        frameRate: FrameRate(30),
                      ),
                    )

                    // Image.asset('assets/inithome/pickupd.png'),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Text('Order Confirmed ✔' , style: GoogleFonts.lexend(fontSize: 25 ,fontWeight: FontWeight.w500 ) , textAlign: TextAlign.center,),
                    // SizedBox(height: 10,),
                    Text('We will be coming for your\nscrap pickup' , style: GoogleFonts.lexend(fontSize: 21 ,fontWeight: FontWeight.w500 ) , textAlign: TextAlign.center,),
                    SizedBox(height: 10,),
                    Text(DateFormat('EEEE , dd MMMM yyyy').format(DateTime.parse(Itemdata['pick_up_date']??'81030-04-01'))??'' , style: GoogleFonts.poppins(fontSize: 14 ,color: const Color(0xFF8D8D8D) , fontWeight: FontWeight.normal) , ),
                    Text('Between 10AM - 6PM' , style: GoogleFonts.poppins(fontSize: 13 ,color: const Color(0xFF8D8D8D) , fontWeight: FontWeight.normal) , ),
                  ],
                ),
              ),

            ],
          ),
        ),
      ),
      floatingActionButton: SizedBox(
        width: double.infinity,
        child: Padding(
          padding: const EdgeInsets.only(left: 20, right: 20, top: 8),
          child: ElevatedButton(
            onPressed: () {
              // Action to be performed on button press
              Navigator.push(context, MaterialPageRoute (
                builder: (BuildContext context) =>  PickStatus(OrderDetails: Itemdata,),
              ),);
            },
            style: ElevatedButton.styleFrom(
              foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
              elevation: 5, // Elevation (shadow)
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(3.0), // Rounded corners
              ),
              padding: EdgeInsets.symmetric(horizontal: 60, vertical: 11), // Button padding
            ),
            child: Text('Pickup Details' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w600),), // Button text
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}
