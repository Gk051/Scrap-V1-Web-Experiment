

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/pickAddress.dart';
import 'package:scrap_app_v2/Services/DataService.dart';
import 'package:scrap_app_v2/Services/ProviderService.dart';

import 'PickMoneymode.dart';

class AddAddress extends StatefulWidget {
  const AddAddress({Key? key}) : super(key: key);

  @override
  State<AddAddress> createState() => _AddAddressState();
}

class _AddAddressState extends State<AddAddress> {
  int _currentIndex = 0;
  String desc = '';
  TextEditingController myController1 = TextEditingController();
  TextEditingController myController2 = TextEditingController();
  void dispose() {
    // Clean up the controller when the widget is disposed.
    myController1.dispose();
    myController2.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(),
      body:
        SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [


              Padding(
                padding: const EdgeInsets.only(left: 25.0 , top: 20),
                child: Text('Confirm Your Pickup' , style: GoogleFonts.lexend(fontSize: 26 ,fontWeight: FontWeight.w600)),
              ),



              Padding(
                  padding: const EdgeInsets.only(left: 8.0 , top: 20 , right: 8  ),
                  child: Column(
                      children:[

                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Address Type' , style: GoogleFonts.poppins(fontSize: 14 ,color: Color(0xff8a8a8a), fontWeight: FontWeight.w500),),
                              const SizedBox(height: 10,),
                              TextFormField(
                                maxLines: 1,
                                controller: myController1,
                                decoration:  InputDecoration(
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Color(0xffa8a8a8),
                                        width: 1.8,
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      // borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                        color: Color(0xff00685c),
                                        width: 1.4,
                                      ),
                                    ),
                                    labelStyle: TextStyle(
                                        color: Color(0xffa8a8a8),
                                        fontSize: 10

                                    ),

                                    hoverColor: Color(0xff00685c)
                                ),
                                keyboardType: TextInputType.text,
                                onFieldSubmitted: (value) {
                                  setState(() {
                                    desc = value;
                                  });
                                },
                                validator: (value) {
                                  if (value!.isEmpty ) {
                                    return 'Invalid desc!';
                                  }
                                  return null;
                                },
                              ),
                              const SizedBox(height: 10,),

                              Text('Address :' , style: GoogleFonts.poppins(fontSize: 14 ,color: Color(0xff8a8a8a), fontWeight: FontWeight.w500),),
                              const SizedBox(height: 10,),
                              TextFormField(
                                maxLines: 3,
                                controller: myController2,
                                decoration:  InputDecoration(
                                  // filled:true,
                                    helperText: 'EX : 12/2 west street  ',
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Color(0xffa8a8a8),
                                        width: 1.8,
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      // borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                        color: Color(0xff00685c),
                                        width: 1.4,
                                      ),
                                    ),
                                    labelStyle: TextStyle(
                                        color: Color(0xffa8a8a8),
                                        fontSize: 10

                                    ),

                                    hoverColor: Color(0xff00685c)
                                ),
                                keyboardType: TextInputType.text,
                                onFieldSubmitted: (value) {
                                  setState(() {
                                    desc = value;
                                  });
                                },
                                validator: (value) {
                                  if (value!.isEmpty ) {
                                    return 'Invalid desc!';
                                  }
                                  return null;
                                },
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 100,)
                      ]
                  )
              ),


            ],
          ),
        ),
      floatingActionButton: ElevatedButton(
        onPressed: () async{
          if(myController1.text != '' && myController2.text != '') {
            var success = await Dataservice().AddAddress(context :context , id: context
                .read<MainProvider>()
                .user_id,
                type: myController1.text,
                address: myController2.text);
            if (success) {
              // Action to be performed on button press
              Navigator.pop(context);
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text("Error Adding Address"),
                  duration: Duration(seconds: 2),
                ),
              );
            }
          }else{
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text("Fill All Fields"),
                duration: Duration(seconds: 2),
              ),
            );
          }
        },
        style: ElevatedButton.styleFrom(
          foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
          elevation: 5, // Elevation (shadow)
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(3.0), // Rounded corners
          ),
          padding: EdgeInsets.symmetric(horizontal: 60, vertical: 11), // Button padding
        ),
        child: Text('Save Address' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w600),), // Button text
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,

    );
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar-15 ,bottom: 5),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Add Location' , style: GoogleFonts.lexend(fontSize: 18 , fontWeight: FontWeight.w500),),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Colors.white12,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.contain,
            ),
          ),
        ),
      ),
    );
  }
}
