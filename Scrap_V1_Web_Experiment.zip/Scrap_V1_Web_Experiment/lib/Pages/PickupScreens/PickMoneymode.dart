

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/EditUPI.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/screen3.dart';
import 'package:scrap_app_v2/Services/ProviderService.dart';

class PickMoneyMode extends StatefulWidget {
  const PickMoneyMode({Key? key}) : super(key: key);

  @override
  State<PickMoneyMode> createState() => _PickMoneyModeState();
}

class _PickMoneyModeState extends State<PickMoneyMode> {
  bool isCash = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(),
      body:
      SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [


            Padding(
              padding: const EdgeInsets.only(left: 25.0 , top: 20),
              child: Text('Select money acceptence mode' , style: GoogleFonts.lexend(fontSize: 26 ,fontWeight: FontWeight.w600)),
            ),



            Padding(
                padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 25 ),
                child: InkWell(
                  onTap: (){
                    context.read<MainProvider>().updateCashStatus(false);
                    context.read<MainProvider>().updatePayment('UPI : ${context.read<MainProvider>().Upi}');
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: context.watch<MainProvider>().isCash?Color(0xff8a8a8a):Color(0xff00685c) , width: 1),
                      borderRadius: BorderRadius.circular(3),
                      color: context.watch<MainProvider>().isCash?Colors.transparent:Color(0xffccebe8),
                    ),
                    width: double.infinity,
                    child: Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Image.asset('assets/inithome/upi.png'),
                          SizedBox(width: 15,),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text('UPI' , style: GoogleFonts.poppins(fontSize: 15 , fontWeight: FontWeight.w500),),
                              InkWell(
                                onTap: (){
                                  Navigator.push(context, MaterialPageRoute (
                                    builder: (BuildContext context) =>  EditUPI(),
                                  ),);
                                },
                                child: Row(
                                  children: [
                                    Text('Via : ${context.watch<MainProvider>().Upi}' , style: GoogleFonts.poppins(fontSize: 11 ),),
                                    SizedBox(width: 10,),
                                    Icon(Icons.edit , size: 15,)
                                  ],
                                ),
                              ),

                            ],
                          ),

                        ],
                      ),
                    ),
                  ),
                )
            ),
            Padding(
                padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 25 ),
                child: InkWell(
                  onTap: (){
                    context.read<MainProvider>().updateCashStatus(true);
                    context.read<MainProvider>().updatePayment('Cash On Pickup');
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: context.watch<MainProvider>().isCash?Color(0xff00685c):Color(0xff8a8a8a) , width: 1),
                      borderRadius: BorderRadius.circular(3),
                      color: context.watch<MainProvider>().isCash?Color(0xffccebe8):Colors.transparent,
                    ),
                    width: double.infinity,
                    child: Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Image.asset('assets/inithome/cash.png'),

                          SizedBox(width: 15,),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Cash' , style: GoogleFonts.poppins(fontSize: 15 , fontWeight: FontWeight.w500),),
                              Text('Get money in cash by our pickup executive' , style: GoogleFonts.poppins(fontSize: 11 ),softWrap: true,),

                            ],
                          ),

                        ],
                      ),
                    ),
                  ),
                )
            ),

          ],
        ),
      ),
      floatingActionButton: Container(
        width: MediaQuery.of(context).size.width-50,
        child: ElevatedButton(
          onPressed: () {
            if(context.read<MainProvider>().Upi.length != 10 && !context.read<MainProvider>().isCash){
              Fluttertoast.showToast(
                msg: "Add Upi to Place Order!",
                toastLength: Toast.LENGTH_SHORT,
                gravity: ToastGravity.BOTTOM,
                backgroundColor: Colors.black,
                textColor: Colors.white,
                fontSize: 16.0,
              );
              context.read<MainProvider>().updateCashStatus(true);
              context.read<MainProvider>().updatePayment('Cash On Pickup');
            }else {
              // Action to be performed on button press
              Navigator.pop(context);
            }
          },
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
            elevation: 5, // Elevation (shadow)
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(3.0), // Rounded corners
            ),
            padding: EdgeInsets.symmetric(horizontal: 60, vertical: 11), // Button padding
          ),
          child: Text('Submit' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w600),), // Button text
        ),
      ),

      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,

    );
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar-15 ,bottom: 12),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Sell Scrap' , style: GoogleFonts.lexend(fontSize: 18 , fontWeight: FontWeight.w500),),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Color(0xff00685C),
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30) , bottomRight: Radius.circular(30))
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}
