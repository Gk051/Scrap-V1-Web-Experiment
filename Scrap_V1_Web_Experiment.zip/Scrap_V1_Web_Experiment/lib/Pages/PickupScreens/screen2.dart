

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/Pages/CategoryHome.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/screen3.dart';
import 'package:intl/intl.dart';
import 'package:scrap_app_v2/Pages/Ratelist/RateList.dart';
import 'package:scrap_app_v2/Services/ProviderService.dart';
class RaiseScreen2 extends StatefulWidget {
  const RaiseScreen2({Key? key }) : super(key: key);
  @override
  State<RaiseScreen2> createState() => _RaiseScreen2State();
}

class _RaiseScreen2State extends State<RaiseScreen2> {
  int _currentIndex = 0;

  DateTime _selectedDate = DateTime.now().hour >= 10 ? DateTime.now().add(Duration(days: 1)) : DateTime.now();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: CustomAppBar(),
      body:  [
        SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 125,),
              Padding(
                padding: const EdgeInsets.only(left:0.0 , top: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          width: 30,
                          height: 2,
                          decoration: BoxDecoration(
                              color: Color(0xffccebe8)
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Color(0xffccebe8)
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text('1 item picked' , style: GoogleFonts.poppins(fontSize: 11 , color: Color(0xff5f5f5f)),),
                          ),
                        ),
                        Container(
                          width: 30,
                          height: 2,
                          decoration: BoxDecoration(
                              color: Color(0xffccebe8)
                          ),
                        ),
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Color(0xff00685c)
                          ),
                        )
                      ],
                    ),
                    Expanded(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [

                          Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: Color(0xff00685c) , width: 1)
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Text('Pickup Data' , style: GoogleFonts.poppins(fontSize: 11 , color: Color(0xff5f5f5f)),),
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              // border: Border.all(color: Color(0xff00685c) , width: 1)
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Text('Confirm' , style: GoogleFonts.poppins(fontSize: 11 , color: Color(0xff5f5f5f)),),
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 25.0 , top: 20),
                child: Text('Select a date for pickup' , style: GoogleFonts.lexend(fontSize: 26 ,fontWeight: FontWeight.w600)),
              ),

              Padding(
                padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 10 ),
                child: Text('Pickup time will be between 9AM to 6PM. Our Pickup executive will call you before coming.' , style: GoogleFonts.poppins(fontSize: 13 , color: Color(0xff585858)),),
              ),

              Padding(
                padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 25 ),
                child: InkWell(
                  onTap: _showDatePicker,
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Color(0xff00685c) , width: 4),
                      borderRadius: BorderRadius.circular(10),
                      color: Color(0xffccebe8),
                    ),
                    width: double.infinity,
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(_selectedDate.day == DateTime.now().day ? 'Today' : _selectedDate.day == DateTime.now().day + 1 ? 'Tomorrow' : DateFormat('EEEE').format(_selectedDate) , style: GoogleFonts.poppins(fontSize: 15 , fontWeight: FontWeight.w500),),
                              Text(DateFormat('dd MMMM yyyy').format(_selectedDate) , style: GoogleFonts.poppins(fontSize: 11 ,color: Color(0xff8a8a8a)),),

                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Icon(Icons.keyboard_arrow_down , size: 50,color: Color(0xff00685c),),
                          )
                        ],
                      ),
                    ),
                  ),
                )
              ),


            ],
          ),
        ),
        Ratelist()
      ][_currentIndex],
      floatingActionButton: _currentIndex==0?
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Container(
          width: MediaQuery.of(context).size.width,
          child: ElevatedButton(

            onPressed: () {
              if(context.read<MainProvider>().Address.isNotEmpty) {
                context.read<MainProvider>().updateDateTime(
                    selectionDate: _selectedDate);
                // Action to be performed on button press
                Navigator.push(context, MaterialPageRoute(
                  builder: (BuildContext context) => RaiseScreen3(),
                ),);
              }
              else{
                Fluttertoast.showToast(
                  msg: "Add Address to Place Order!",
                  toastLength: Toast.LENGTH_SHORT,
                  gravity: ToastGravity.BOTTOM,
                  backgroundColor: Colors.black,
                  textColor: Colors.white,
                  fontSize: 16.0,
                );
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => CategoryHome(User_id: context.read<MainProvider>().user_id)),
                      (Route<dynamic> route) => false, // Condition to retain certain routes
                );
              }
            },

            style: ElevatedButton.styleFrom(
              disabledBackgroundColor: Color(0xff00685c).withOpacity(0.4),
              disabledForegroundColor: Colors.white,
              foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
              elevation: 5, // Elevation (shadow)
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(3.0), // Rounded corners
              ),
              padding: EdgeInsets.symmetric( vertical: 11), // Button padding
            ),
            child: Text('Continue' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w600),), // Button text
          ),
        ),
      )
          :SizedBox(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        elevation: 0,
        type:BottomNavigationBarType.fixed,
        selectedItemColor: Color(0xff184d47),
        unselectedItemColor: Color(0xff184d47),
        selectedLabelStyle: GoogleFonts.poppins(fontWeight: FontWeight.w600),
        unselectedLabelStyle: GoogleFonts.poppins(),
        selectedFontSize: 18,
        unselectedFontSize: 18,
        items: [
          BottomNavigationBarItem(

            icon: _currentIndex == 0?Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: EdgeInsets.zero,
                  width: double.infinity,
                  height: 5,
                  color: Color(0xff184d47),
                ),
                SizedBox(height: 8,),
                Image.asset('assets/inithome/icon-bnavbar.png'),
              ],
            ):Image.asset('assets/inithome/icon-bnavbar.png'),
            label: 'Sell Scrap',
          ),
          BottomNavigationBarItem(
            icon: _currentIndex == 1?Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: EdgeInsets.zero,
                  width: double.infinity,
                  height: 5,
                  color: Color(0xff184d47),
                ),
                SizedBox(height: 8,),
                Image.asset('assets/inithome/icon-bnavbar2.png'),
              ],
            ):Image.asset('assets/inithome/icon-bnavbar2.png'),
            label: 'Rate List',
          ),

        ],
      ),
    );
  }
  void _showDatePicker()  async{
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now().hour >= 10 ? DateTime.now().add(Duration(days: 1)) : DateTime.now() ,
      firstDate: DateTime.now().hour >= 10 ? DateTime.now().add(Duration(days: 1)) : DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 7)),
      currentDate: _selectedDate,
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.dark().copyWith(
            primaryColor: Color(0xff00685c), // Change the header background color
            cardColor: Color(0xff00685c), // Change the selection color
            colorScheme: ColorScheme.light(
              primary: Color(0xff00685c), // Change the text color
            ),
            buttonTheme: ButtonThemeData(
              textTheme: ButtonTextTheme.primary, // Change the button text color
            ),
          ),
          child: child as Widget,
        );
      },
    );

    if (pickedDate != null) {
      setState(() {

        _selectedDate = pickedDate;
        context.read<MainProvider>().updateDateTime(selectionDate: _selectedDate);
      });
    }
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar-15,bottom: 10),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Sell Scrap' , style: GoogleFonts.lexend(fontSize: 18 , fontWeight: FontWeight.w500),),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Color(0xff00685C),
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30) , bottomRight: Radius.circular(30))
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}
