

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/PickMoneymode.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/screen3.dart';
import 'package:scrap_app_v2/Services/ProviderService.dart';

class EditUPI extends StatefulWidget {
  const EditUPI({Key? key}) : super(key: key);

  @override
  State<EditUPI> createState() => _EditUPIState();
}

class _EditUPIState extends State<EditUPI> {
  String upi ='';
  TextEditingController myController1 = TextEditingController();
  void dispose() {
    // Clean up the controller when the widget is disposed.
    myController1.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(),
      body:
      SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 25.0 , top: 20),
              child: Image.asset('assets/inithome/upi.png'),
            ),
  
            Padding(
              padding: const EdgeInsets.only(left: 25.0 , top: 20),
              child: Text('Enter UPI ID to Verify' , style: GoogleFonts.lexend(fontSize: 26 ,fontWeight: FontWeight.w600)),
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  TextFormField(
                    maxLines: 1,
                    controller: myController1,
                    decoration:  InputDecoration(
                      // filled:true,
                        helperText: 'EX : 8329XXXX23  ',
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Color(0xffa8a8a8),
                            width: 1.8,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          // borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(
                            color: Color(0xff00685c),
                            width: 1.4,
                          ),
                        ),
                        labelStyle: TextStyle(
                            color: Color(0xffa8a8a8),

                        ),
  labelText: 'UPI ID',
                        hoverColor: Color(0xff00685c)
                    ),
                    keyboardType: TextInputType.number,
                    onFieldSubmitted: (value) {
                      setState(() {
                        upi = value;
                      });
                    },
                    validator: (value) {
                      if (value!.isEmpty ) {
                        return 'Invalid desc!';
                      }
                      return null;
                    },
                  ),
                  TextButton(onPressed: (){
                    if(myController1.text.length == 10){
                      Fluttertoast.showToast(
                        msg: "Verification Successful",
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.BOTTOM,
                        backgroundColor: Colors.black,
                        textColor: Colors.white,
                        fontSize: 16.0,
                      );
                    }else{
                      Fluttertoast.showToast(
                        msg: "Invalid Mobile Number",
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.BOTTOM,
                        backgroundColor: Colors.black,
                        textColor: Colors.white,
                        fontSize: 16.0,
                      );
                    }
                  }, child: Text('Verify' , style: GoogleFonts.lexend(fontSize: 15 , color: Color(0xff00685c)),))
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: ElevatedButton(
        onPressed: () {
          // Action to be performed on button press
          context.read<MainProvider>().updateUpiStatus(myController1.text);
          context.read<MainProvider>().updatePayment('UPI : ${myController1.text}');
          Navigator.pop(context);
        },
        style: ElevatedButton.styleFrom(
          foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
          elevation: 5, // Elevation (shadow)
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(3.0), // Rounded corners
          ),
          padding: EdgeInsets.symmetric(horizontal: 60, vertical: 11), // Button padding
        ),
        child: Text('Submit' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w600),), // Button text
      ),

      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,

    );
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar-15 ,bottom: 5),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Sell Scrap' , style: GoogleFonts.lexend(fontSize: 18 , fontWeight: FontWeight.w500),),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Colors.white12,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.contain,
            ),
          ),
        ),
      ),
    );
  }
}
