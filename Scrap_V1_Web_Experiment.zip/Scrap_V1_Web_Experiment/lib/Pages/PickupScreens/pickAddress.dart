

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/screen3.dart';
import 'package:scrap_app_v2/Services/ProviderService.dart';

class PickAddress extends StatefulWidget {
  const PickAddress({Key? key}) : super(key: key);

  @override
  State<PickAddress> createState() => _PickAddressState();
}

class _PickAddressState extends State<PickAddress> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    List<dynamic> addresses = context.read<MainProvider>().Address;
    return Scaffold(
      appBar: CustomAppBar(),
      body:
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [


            Padding(
              padding: const EdgeInsets.only(left: 25.0 , top: 20),
              child: Text('Select Pickup Address' , style: GoogleFonts.lexend(fontSize: 26 ,fontWeight: FontWeight.w600)),
            ),

            SingleChildScrollView(
              child: Container(
                decoration: BoxDecoration(
                  // color: Colors.red
                ),
                constraints: BoxConstraints(
                    minHeight: 0,
                    maxHeight: 500
                ),
                child: ListView.builder(
                  itemCount: addresses.length,
                  itemBuilder: (context, index) {
                    final address = addresses[index];
                    return Padding(
                      padding: const EdgeInsets.only( left: 25.0 , top: 20 , right: 25  ),
                      child:InkWell(
                          onTap: (){


                            context.read<MainProvider>().updateAddressIndex(index: index);

                          },
                          child:  Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: context.watch<MainProvider>().selectedAddressindex == index ?Color(0xff00685c):Color(0xff8a8a8a) , width: 1),
                              borderRadius: BorderRadius.circular(3),
                              color: context.watch<MainProvider>().selectedAddressindex == index ?Color(0xffccebe8):Colors.transparent,
                            ),
                            width: double.infinity,
                            child: Padding(
                              padding: const EdgeInsets.all(15.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(address['type'].toString() , style: GoogleFonts.poppins(fontSize: 16 , fontWeight: FontWeight.w500),),
                                        Text(address['address'] , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w400 ),overflow: TextOverflow.ellipsis,maxLines: 1,),

                                      ],
                                    ),
                                  ),
                                  IconButton(onPressed: (){}, icon: Icon(Icons.delete , size: 30 , color: Color(0xff00685c),))
                                ],
                              ),
                            ),
                          )
                      ),
                    );
                  },
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 1,
                    width: 100,
                    color: Color(0xff8a8a8a),
                  ),
                  SizedBox(width: 10,),
                  Text('OR' , style: GoogleFonts.lexend(fontSize: 10,),),
                  SizedBox(width: 10,),
                  Container(
                    height: 1,
                    width: 100,
                    color: Color(0xff8a8a8a),
                  ),
                ],
              ),
            ),
            TextButton(
              onPressed: (){

              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.add_circle_outline , size: 25, color: Color(0xff00685c),),
                  SizedBox(width: 10,),
                  Text('Add Address' , style: GoogleFonts.poppins(fontSize: 15 , color: Color(0xff00685c),fontWeight: FontWeight.w600)),
                ],
              ),
            )
          ],
        ),



    );
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar-15 ,bottom: 12),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Sell Scrap' , style: GoogleFonts.lexend(fontSize: 18 , fontWeight: FontWeight.w500),),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Color(0xff00685C),
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30) , bottomRight: Radius.circular(30))
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}
