import 'package:flutter/cupertino.dart';
import 'package:scrap_app_v2/Components/LoadingOrError.dart';
import 'package:scrap_app_v2/Services/http_with_timeout.dart' show friendlyError;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/screen2.dart';
import 'package:scrap_app_v2/Pages/Ratelist/RateList.dart';
import 'package:scrap_app_v2/Services/DataService.dart';
import 'package:scrap_app_v2/Services/ProviderService.dart';

import '../../Services/LoaderService.dart';

class RaiseScreen1 extends StatefulWidget {
  const RaiseScreen1({Key? key , required this.category_id , required this.category_name}) : super(key: key);
  final int category_id;
  final String category_name;
  @override
  State<RaiseScreen1> createState() => _RaiseScreen1State();
}

class _RaiseScreen1State extends State<RaiseScreen1> {
  int _currentIndex = 0;
  int? ItemdataIndex;
  List<dynamic> Itemdata = [
    {"paper":[{"product_name": "Option 1" , "description":"paper" , "price" :23, "measurement":"kg" }]}
  ];
  // WEB EXPERIMENT: failed request -> message + "Try again" instead of endless loader.
  String? _loadError;

  dynamic getProducts({required int id})async{
    final loader = context.read<LoaderProvider>();
    try {
      final data = await Dataservice().GetProducts(id: id);
      if (data is! List) {
        throw const FormatException('Unexpected products response');
      }
      Itemdata = data;
      _loadError = null;
    } catch (e) {
      _loadError = friendlyError(e);
    }
    loader.hideLoader();
    if (!mounted) return;
    setState(() {

    });
  }

  void _reload() {
    setState(() {
      _loadError = null;
    });
    context.read<LoaderProvider>().showLoader();
    getProducts(id: widget.category_id);
  }
  @override
  void initState() {
    super.initState();
    print(widget.category_id);
    context.read<LoaderProvider>().showLoader();
    getProducts(id: widget.category_id);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: CustomAppBar(),
      body: (context.watch<LoaderProvider>().isLoading || (_loadError != null && _currentIndex == 0))?LoadingOrError(error: _currentIndex == 0 ? _loadError : null, onRetry: _reload):[
        SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 125,),
              Padding(
                padding: const EdgeInsets.only(left: 0.0, top: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          width: 30,
                          height: 2,
                          decoration: BoxDecoration(color: Color(0xffccebe8)),
                        ),
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Color(0xff00685c)),
                        )
                      ],
                    ),
                    Expanded(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Container(
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: Color(0xff00685c), width: 1)),
                            child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Text(
                                'Scrap items',
                                style: GoogleFonts.poppins(
                                    fontSize: 11, color: Color(0xff5f5f5f)),
                              ),
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                                // border: Border.all(color: Color(0xff00685c) , width: 1)
                                ),
                            child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Text(
                                'Pickup Data',
                                style: GoogleFonts.poppins(
                                    fontSize: 11, color: Color(0xff5f5f5f)),
                              ),
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                                // border: Border.all(color: Color(0xff00685c) , width: 1)
                                ),
                            child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Text(
                                'Confirm',
                                style: GoogleFonts.poppins(
                                    fontSize: 11, color: Color(0xff5f5f5f)),
                              ),
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 25.0, top: 20),
                child: Text('Select Scrap items for Pickup',
                    style: GoogleFonts.lexend(
                        fontSize: 26, fontWeight: FontWeight.w600)),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 25.0, top: 10),
                child: Text(
                  'Price may fluctuate because of the recycling industry',
                  style: GoogleFonts.poppins(
                      fontSize: 13, color: Color(0xff585858)),
                ),
              ),
              for(dynamic items in Itemdata)
              Padding(
                padding: const EdgeInsets.only(left: 28.0, top: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    for(String key in items.keys)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          key,
                          style: GoogleFonts.poppins(fontSize: 16),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Wrap(
                          spacing: 15,
                          runSpacing: 15,
                          children: (items[key] as List<dynamic>).map((item) {
                            print(item);
                            int index = item[key] != null ? item[key].indexOf(item) : 0;
                            return GestureDetector(
                              onTap: () {
                                setState(() {
                                  context.read<MainProvider>().updateSelectedProduct(data: item);
                                  ItemdataIndex = index;
                                });
                              },
                              child: Container(
                                width: 113,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                      color: ItemdataIndex == index ?Color(0xff00988a):Color(0xff8a8a8a), // Border color
                                      width: 2.5, // Border width
                                    ),
                                    borderRadius: BorderRadius.circular(5),
                                    color:ItemdataIndex == index ? Color(0xff00988a).withOpacity(0.2):Colors.transparent

                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Row(
                                        mainAxisAlignment: MainAxisAlignment.end,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                right: 4.0, top: 4),
                                            child: Icon(ItemdataIndex == index ?Icons.check_circle:Icons.check_circle_outline , size: 22, color: ItemdataIndex == index ?Color(0xff00988a):Color(0xff8a8a8a),),

                                          ),
                                        ]),
                                    Padding(
                                      padding: const EdgeInsets.only(right: 5.0,left: 5,bottom: 4,top: 5),
                                      child: Text(
                                        item['product_name'],
                                        style: GoogleFonts.poppins(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w500),
                                        softWrap: true,
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(right: 5.0,left: 5,bottom: 8,top: 0),
                                      child: Text(
                                        item['description'],
                                        style: GoogleFonts.poppins(
                                            fontSize: 11, color: Color(0xff585858)),
                                      ),
                                    ),
                                    Container(
                                        width: double.infinity,
                                        height: 30,
                                        decoration: BoxDecoration(
                                          color: Color(0xff408e85),
                                        ),
                                        child: Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              '₹${item['price']}/${item['measurement']}',
                                              style: GoogleFonts.poppins(
                                                  fontSize: 12,
                                                  color: Colors.white),
                                            )
                                          ],
                                        ))
                                  ],
                                ),
                              ),
                            );
                          }).toList(),
                        )
                      ],
                    ),



                  ],

                ),
              ),

            ],
          ),
        ),
        Ratelist()
      ][_currentIndex],
      floatingActionButton: _currentIndex == 0
          ? Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Container(
          width: MediaQuery.of(context).size.width,
          child: ElevatedButton(

            onPressed: ItemdataIndex != null?() {
              // Action to be performed on button press
              // context.read<MainProvider>().updateSelectedProduct(data: Itemdata[ItemdataIndex!]);
              Navigator.push(context, MaterialPageRoute (
                builder: (BuildContext context) =>  RaiseScreen2(),
              ),);
            }:null,

            style: ElevatedButton.styleFrom(
              disabledBackgroundColor: Color(0xff00685c).withOpacity(0.4),
              disabledForegroundColor: Colors.white,
              foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
              elevation: 5, // Elevation (shadow)
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(3.0), // Rounded corners
              ),
              padding: EdgeInsets.symmetric( vertical: 11), // Button padding
            ),
            child: Text('Continue' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w600),), // Button text
          ),
        ),
      )
          : SizedBox(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        elevation: 0,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Color(0xff184d47),
        unselectedItemColor: Color(0xff184d47),
        selectedLabelStyle: GoogleFonts.poppins(fontWeight: FontWeight.w600),
        unselectedLabelStyle: GoogleFonts.poppins(),
        selectedFontSize: 18,
        unselectedFontSize: 18,
        items: [
          BottomNavigationBarItem(
            icon: _currentIndex == 0
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: EdgeInsets.zero,
                        width: double.infinity,
                        height: 5,
                        color: Color(0xff184d47),
                      ),
                      SizedBox(
                        height: 8,
                      ),
                      Image.asset('assets/inithome/icon-bnavbar.png'),
                    ],
                  )
                : Image.asset('assets/inithome/icon-bnavbar.png'),
            label: 'Sell Scrap',
          ),
          BottomNavigationBarItem(
            icon: _currentIndex == 1
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: EdgeInsets.zero,
                        width: double.infinity,
                        height: 5,
                        color: Color(0xff184d47),
                      ),
                      SizedBox(
                        height: 8,
                      ),
                      Image.asset('assets/inithome/icon-bnavbar2.png'),
                    ],
                  )
                : Image.asset('assets/inithome/icon-bnavbar2.png'),
            label: 'Rate List',
          ),
        ],
      ),
    );
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar - 15, bottom: 10),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    'Sell Scrap',
                    style: GoogleFonts.lexend(
                        fontSize: 18, fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Color(0xff00685C),
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30) , bottomRight: Radius.circular(30))
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage(
                  'assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}
