import 'package:flutter/material.dart';
import 'package:scrap_app_v2/Components/LoadingOrError.dart';
import 'package:scrap_app_v2/Services/http_with_timeout.dart' show friendlyError;
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/Services/DataService.dart';
import 'package:scrap_app_v2/Services/ProviderService.dart';

import '../../Services/LoaderService.dart';

class Ratelist extends StatefulWidget {
  const Ratelist({super.key});

  @override
  State<Ratelist> createState() => _RatelistState();
}

class _RatelistState extends State<Ratelist> {
  Map rateList = {};
  // WEB EXPERIMENT: failed request -> message + "Try again" instead of endless loader.
  String? _loadError;

  void getRateList() async {
    final loader = context.read<LoaderProvider>();
    loader.showRateListLoader();
    try {
      if(context.read<MainProvider>().rateList.isEmpty){
        rateList = await Dataservice().FetchRateList(context: context);
        final data = rateList['data'];
        if (data is! List) {
          throw const FormatException('Unexpected rate list response');
        }
        if (!mounted) return;
        context.read<MainProvider>().updateRateList(data: data);
      }
      _loadError = null;
    } catch (e) {
      _loadError = friendlyError(e);
    }
    loader.hideRateListLoader();
    if (!mounted) return;
    setState(() {});
  }

  void _reload() {
    setState(() {
      _loadError = null;
    });
    getRateList();
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getRateList();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        extendBodyBehindAppBar: true,
        appBar: CustomAppBar(),
        body:
     ((context.watch<LoaderProvider>().isRateListLoading || _loadError != null) && context.watch<MainProvider>().rateList.isEmpty)?LoadingOrError(error: _loadError, onRetry: _reload):

    SingleChildScrollView(

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 125,),

          Padding(
            padding: const EdgeInsets.only(left: 25.0 , top: 20),
            child: Text('Today\'s scrap price list ', style: GoogleFonts.lexend(fontSize: 25 ,fontWeight: FontWeight.w600)),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 28.0 , top: 20 ),
            child: Text('Price may fluctuate because of the recycling industry' , style: GoogleFonts.poppins(fontSize: 12 , color: Color(0xff585858)),),
          ),
          Column(
              children: context.read<MainProvider>().rateList.map((item){
                return Padding(
                  padding: const EdgeInsets.only(left: 28.0 , top: 20 ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item['category'] , style: GoogleFonts.poppins(fontSize:15 ),),
                      SizedBox(height: 5,),
                      Wrap(
                          spacing: 15,
                          runSpacing: 15,
                          children:
                          item['items'].map<Widget>((e){
                            return Container(
                              width: 113,
                              decoration: BoxDecoration(
                                  border: Border.all(
                                    color: Color(0xff8a8a8a), // Border color
                                    width: 2.5, // Border width
                                  ),
                                  borderRadius: BorderRadius.circular(5)
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [

                                  Padding(
                                    padding: const EdgeInsets.all(5.0),
                                    child: Text(e['product_name']  , style: GoogleFonts.poppins(fontSize: 12 , fontWeight: FontWeight.w500),),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(5.0),
                                    child: Text(e['description'] , style: GoogleFonts.poppins(fontSize: 11 , color: Color(0xff585858)),),
                                  ),
                                  Container(
                                      width: double.infinity,
                                      // height: 30,
                                      decoration: BoxDecoration(
                                        color: Color(0xff408e85),

                                      ),
                                      constraints:BoxConstraints(
                                          minHeight: 30,
                                          maxHeight: 60
                                      ),
                                      child:Padding(
                                        padding: const EdgeInsets.all(5.0),
                                        child: Text('₹${e['price']}/${e['measurement']}' , style: GoogleFonts.poppins(fontSize: 12 , color: Colors.white ,),overflow: TextOverflow.ellipsis,maxLines: 2,softWrap: true,textAlign: TextAlign.center,),
                                      )
                                  )
                                ],
                              ),
                            );
                          }).toList()

                      ),

                    ],
                  ),
                )as Widget;}).toList()
          )




        ],
      ),
    )
    );
  }
}


class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar - 15, bottom: 10),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    'Sell Scrap',
                    style: GoogleFonts.lexend(
                        fontSize: 18, fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Color(0xff00685C),
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30) , bottomRight: Radius.circular(30))
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage(
                  'assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}