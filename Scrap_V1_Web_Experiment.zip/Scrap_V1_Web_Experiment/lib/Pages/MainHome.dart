// import 'package:flare_flutter/flare_actor.dart';
import 'package:flutter/foundation.dart' show kIsWeb, debugPrint;
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:scrap_app_v2/Pages/Authenticate/Authenticate.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'initialscreens/firstscreen.dart';

// WEB EXPERIMENT changes in this file:
//  * The first-run check is failure-tolerant and checks `mounted`.
//  * The placeholder SplashScreen no longer builds a second Authenticate()
//    (the original built one here AND navigated to another one, so two login
//    checks ran at once). It now only shows the logo with a spinner.
//  * FlutterNativeSplash.remove() is skipped on the web (there is none).
class MainHome extends StatefulWidget {
  const MainHome({Key? key}) : super(key: key);

  @override
  State<MainHome> createState() => _MainHomeState();
}

class _MainHomeState extends State<MainHome> {
  late bool isFirstTime = false;
  Future<void> shared() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      isFirstTime = prefs.getBool('isFirstTime') ?? true;
      if (isFirstTime) {
        await prefs.setBool('isFirstTime', false);
      }
    } catch (e) {
      // If preferences cannot be read, skip the intro and go to sign-in.
      debugPrint('MainHome: could not read preferences: $e');
      isFirstTime = false;
    }
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
            builder: (BuildContext context) =>
                isFirstTime ? FirstScreen() : Authenticate()),
        (route) => false);
  }

  @override
  void initState() {
    super.initState();
    if (!kIsWeb) {
      FlutterNativeSplash.remove();
    }
    shared();
  }

  @override
  Widget build(BuildContext context) {
    return SplashScreen(isFirstTime: isFirstTime);
  }
}

class SplashScreen extends StatelessWidget {
  final bool isFirstTime;

  SplashScreen({required this.isFirstTime});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/inithome/ep.png', width: 150, height: 150),
            SpinKitFadingCircle(
              color: Color(0xff00685c),
            ),
          ],
        ),
      ),
    );
  }
}

class MainScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    // Your main screen content goes here
    return Scaffold(
      appBar: AppBar(
        title: Text('Main Screen'),
      ),
      body: Center(
        child: Text('Welcome to your app!'),
      ),
    );
  }
}
