import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/Constants/globalLoader.dart';
import 'package:scrap_app_v2/Pages/Authenticate/login.dart';
import 'package:scrap_app_v2/Pages/Authenticate/signup.dart';

import '../../Services/LoaderService.dart';
import '../../Services/ProviderService.dart';
import '../../Services/SecureStorageServices.dart';
import '../CategoryHome.dart';

class Authenticate extends StatefulWidget {
  const Authenticate({super.key});

  @override
  State<Authenticate> createState() => _AuthenticateState();
}

class _AuthenticateState extends State<Authenticate> {
  final SecureStorage _secureStorage = SecureStorage();
  bool _isLoading = true;
  @override
  void initState() {
    // TODO: implement initState


    super.initState();
    // WEB EXPERIMENT: the stored-session check can no longer leave the screen
    // spinning. Any storage error or invalid stored id is treated as "not
    // signed in", the stale value is cleared, and the login sheet is shown.
    Future.delayed( Duration(seconds: 2), () async{
      if (!mounted) return;
      int? userId;
      try {
        final stored = await _secureStorage.getData('user_id');
        if (stored != null) {
          userId = int.tryParse(stored);
          if (userId == null) {
            await _secureStorage.deleteData('user_id');
          }
        }
      } catch (_) {
        userId = null;
      }
      if (!mounted) return;

      if (userId != null) {
        context.read<MainProvider>().updateUserId(id: userId);
        context.read<LoaderProvider>().hideLoader();
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => CategoryHome(User_id: userId!,)),
              (Route<dynamic> route) => false, // Condition to retain certain routes
        );
      } else {
        // Not signed in: clear any stale loader flag and show the login sheet
        context.read<LoaderProvider>().hideLoader();
        setState(() {
          _isLoading = false;
        });
        showModalBottomSheet(context: context, builder: (context)=>Login() , shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(topRight: Radius.circular(40), topLeft: Radius.circular(40))
        ),
            isScrollControlled: true,
            isDismissible: false,
            constraints: BoxConstraints(
              // minHeight: 500
            )
        );
      }
    });

  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: _isLoading?Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/inithome/ep.png' , width: 150,height: 150,),
            SpinKitFadingCircle(
              color: Color(0xff00685c),
            )
          ],
        ),

      ):Center(
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: Image.asset('assets/32.jpg' , fit: BoxFit.cover,),
        ),
      ),
      floatingActionButton: _isLoading!=true?Container(
        width: MediaQuery.of(context).size.width,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [

            InkWell(
              onTap: (){
                // print(MediaQuery.of(context).size.height/1.5);
                showModalBottomSheet(context: context, builder: (context)=>Login() , shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.only(topRight: Radius.circular(40), topLeft: Radius.circular(40))
                ),
                  isScrollControlled: true,
                  isDismissible:false,
                  constraints: BoxConstraints(
                    // minHeight: 500
                  )
                );
              },
              child: Container(
                height: 70,
                width: MediaQuery.of(context).size.width/2 - 2,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(topRight: Radius.circular(36)),
                  color: Color.fromRGBO(255, 255, 255, 0.7),
                  gradient: LinearGradient(
                      colors: [
                        Color(0xffdbdbdb),
                        Color(0xff181818),
                  ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter

                  )
                ),
                child: Center(child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text('Sign In' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w500 , color: Color(0xfff8f8f8)),),
                )),
              ),
            ),
            InkWell(
              onTap: (){
                showModalBottomSheet(context: context, builder: (context)=>Signup() , shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.only(topRight: Radius.circular(40), topLeft: Radius.circular(40))
                ),
                    isScrollControlled: true,
                    constraints: BoxConstraints(
                        // minHeight: 565
                    )
                );
              },
              child: Container(
                height: 70,
                width: MediaQuery.of(context).size.width/2 - 2,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(36)),
                  color: Color.fromRGBO(255, 255, 255, 0.7),
                    gradient: LinearGradient(
                        colors: [
                          Color(0xffdbdbdb),
                          Color(0xff181818),
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter

                    )
                ),
                child: Center(child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text('Sign Up' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w500 , color: Color(0xfff8f8f8)),),
                )),
              ),
            )
          ],
        ),
      ):SizedBox(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}
