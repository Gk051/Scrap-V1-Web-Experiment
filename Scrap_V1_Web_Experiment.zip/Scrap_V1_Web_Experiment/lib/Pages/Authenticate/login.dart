import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/Pages/Authenticate/forgotPassword.dart';
import 'package:scrap_app_v2/Pages/Authenticate/signup.dart';
import 'package:scrap_app_v2/Pages/CategoryHome.dart';
import 'package:scrap_app_v2/Services/AuthenticateService.dart';
import 'package:scrap_app_v2/Services/ProviderService.dart';
import 'package:scrap_app_v2/Services/http_with_timeout.dart' show friendlyError;

import '../../Services/LoaderService.dart';
import '../../Services/SecureStorageServices.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final SecureStorage _secureStorage = SecureStorage();
  TextEditingController myController1 = TextEditingController();
  TextEditingController myController2 = TextEditingController();
  bool passwordVisible = true;
  String helper = '';
  void dispose() {
    // Clean up the controller when the widget is disposed.
    myController1.dispose();
    myController2.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return context.watch<LoaderProvider>().isLoading?Center(
      child: SpinKitCircle(
        color: Color(0xff00685c), // Spinner color
        size: 50.0,          // Spinner size
      ),
    ):SingleChildScrollView(child: Padding(
      padding: const EdgeInsets.all(30.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
              width: MediaQuery.of(context).size.width,
              // height: 300,
              padding: MediaQuery.of(context).viewInsets,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text('Welcome Back' , style: GoogleFonts.poppins(fontSize: 26 , fontWeight: FontWeight.w600 , color: Color(0xff184d47)),),
                  SizedBox(height: 20,),
                  Row(
                    children: [
                      Text('Username / mobile number' , style: GoogleFonts.poppins(fontWeight: FontWeight.w500 , fontSize: 16),textAlign: TextAlign.start,),
                    ],
                  ),
                  SizedBox(height: 5,),
                  TextFormField(

                    style: GoogleFonts.poppins(fontSize: 14 ),
                    maxLines: 1,
                    controller: myController1,
                    decoration:  InputDecoration(
                      // filled:true,
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Color(0xffa8a8a8),
                            width: 1.8,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          // borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(
                            color: Color(0xff00685c),
                            width: 1.4,
                          ),
                        ),
                        labelStyle: TextStyle(
                          color: Color(0xffa8a8a8),

                        ),
                        labelText: 'Enter Username or mobile no.',
                        hoverColor: Color(0xff00685c)
                    ),
                    keyboardType: TextInputType.text,
                    onFieldSubmitted: (value) {
                      setState(() {
                      });
                    },
                    validator: (value) {
                      if (value!.isEmpty ) {
                        return 'Invalid Username!';
                      }
                      return null;
                    },
                  ),

                  SizedBox(height: 14,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Password' , style: GoogleFonts.poppins(fontWeight: FontWeight.w500 , fontSize: 16),textAlign: TextAlign.start,),
                      TextButton(
                        style: TextButton.styleFrom(
                          minimumSize: Size(0, 0), // removes min height
                          padding: EdgeInsets.zero,
                          tapTargetSize:
        MaterialTapTargetSize.shrinkWrap,
                        ),
                        onPressed: (){
                           Navigator.push(context, MaterialPageRoute (
            builder: (BuildContext context) =>  ForgotPassword(),
          ),);
                        },
                        child: Text('Forgot Password?' ,  style: GoogleFonts.poppins(fontWeight: FontWeight.w500 , fontSize: 14 , color: Colors.blue), textAlign: TextAlign.start,)),
                    
                    ],
                  ),
                  SizedBox(height: 5,),
                  TextFormField(

                    style: GoogleFonts.poppins(fontSize: 14 ),
                    maxLines: 1,
                    controller: myController2,
                    obscureText: passwordVisible,

                    decoration:  InputDecoration(
                      // filled:true,
                        suffixIcon: IconButton(
                          icon: Icon(passwordVisible
                              ? Icons.visibility
                              : Icons.visibility_off,
                            color: Color(0xff848484),),
                          onPressed: () {
                            setState(() {
                              passwordVisible = !passwordVisible;
                            });
                          },

                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Color(0xffa8a8a8),
                            width: 1.8,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          // borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(
                            color: Color(0xff00685c),
                            width: 1.4,
                          ),
                        ),
                        labelStyle: TextStyle(
                          color: Color(0xffa8a8a8),

                        ),
                        labelText: 'Enter Password',
                        hoverColor: Color(0xff00685c)
                    ),
                    keyboardType: TextInputType.visiblePassword,
                    onFieldSubmitted: (value) {
                      setState(() {
                      });
                    },
                    validator: (value) {
                      if (value!.isEmpty ) {
                        return 'Invalid Username!';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 5,),
                  Row(
                    children: [
                      Text(helper ,  style: GoogleFonts.poppins(fontWeight: FontWeight.w400 , fontSize: 14 , color: Colors.red), textAlign: TextAlign.start,),
                    ],
                  ),
                  SizedBox(height: 5,),
                  ElevatedButton(
                    onPressed: () async {
                      // WEB EXPERIMENT: the request is wrapped so a network error,
                      // timeout or non-JSON reply always clears the loader and
                      // shows a message (it used to spin forever).
                      final loader = context.read<LoaderProvider>();
                      loader.showLoader();
                      if(myController1.text.isNotEmpty && myController2.text.isNotEmpty){
                        try {
                          var response = await Authenticateservice().Login(Username: myController1.text, Password: myController2.text);
                          final body = jsonDecode(response.body);
                          if (body['code'] == 200) {
                            final userId = int.parse(body['user_id'].toString());
                            await _secureStorage.saveData('user_id', userId.toString());
                            if (!mounted) return;
                            context.read<MainProvider>().updateUserId(id: userId);

                            loader.hideLoader();
                            Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(builder: (context) => CategoryHome(User_id: userId,)),
                              (Route<dynamic> route) => false, // Condition to retain certain routes
                            );
                          } else {
                            loader.hideLoader();
                            if (!mounted) return;
                            setState(() {
                              helper = 'Username or Password is incorrect';
                            });
                          }
                        } catch (e) {
                          loader.hideLoader();
                          if (!mounted) return;
                          setState(() {
                            helper = friendlyError(e);
                          });
                        }
                      }else{
                        loader.hideLoader();
                        setState(() {
                          helper = 'Enter all fields';
                        });
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Enter all fields')));
                      }
                      // Navigator.push(context, MaterialPageRoute (
                      //   builder: (BuildContext context) =>  PickAddress(),
                      // ),);
                    },
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
                      elevation: 5, // Elevation (shadow)
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(3.0), // Rounded corners
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 60, vertical: 11), // Button padding
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('Sign In' , style: GoogleFonts.poppins(fontSize: 19 , fontWeight: FontWeight.w600),textAlign: TextAlign.center,),
                      ],
                    ), // Button text
                  ),

                ],
              )
          ),
          SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Don’t have an account ?' , style: GoogleFonts.poppins(fontSize: 15 , fontWeight: FontWeight.w500 , color: Color(0xff343434)),),
              TextButton(onPressed: (){
                Navigator.pop(context);
                showModalBottomSheet(context: context, builder: (context)=>Signup() , shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.only(topRight: Radius.circular(40), topLeft: Radius.circular(40))
                ),
                    isScrollControlled: true,
                    isDismissible: false,
                    constraints: BoxConstraints(
                      // minHeight: 565
                    )
                );
              }, child: Text('Sign Up' , style: GoogleFonts.poppins(fontSize: 15 , fontWeight: FontWeight.w600 , color: Color(0xff184d47))))
            ],
          )
        ],
      ),
    ));
  }
}
