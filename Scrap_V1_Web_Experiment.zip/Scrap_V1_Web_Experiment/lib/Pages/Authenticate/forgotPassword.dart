

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/pickAddress.dart';
import 'package:scrap_app_v2/Services/AuthenticateService.dart';


class ForgotPassword extends StatefulWidget {
  const ForgotPassword({Key? key}) : super(key: key);

  @override
  State<ForgotPassword> createState() => _ForgotPasswordState();
}

class _ForgotPasswordState extends State<ForgotPassword> {
  int _currentIndex = 0;
  String desc = '';
  TextEditingController myController1 = TextEditingController();
  void dispose() {
    // Clean up the controller when the widget is disposed.
    myController1.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: CustomAppBar(),
      body:
        SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 125,),
              Padding(
                padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 10 ),
                child: Image.asset('assets/inithome/ep.png'),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 25.0 , top: 20),
                child: Text('Type your Email' , style: GoogleFonts.montserrat(fontSize: 26,color: Color(0xff00685c) ,fontWeight: FontWeight.w500)),
              ),



              Padding(
                  padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 25  ),
                  child: TextFormField(
                    maxLines: 1,
                    controller: myController1,
                    decoration:  InputDecoration(
                      // filled:true,

                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Color(0xffa8a8a8),
                            width: 1.8,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          // borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(
                            color: Color(0xff00685c),
                            width: 1.4,
                          ),
                        ),
                        labelStyle: TextStyle(
                            color: Color(0xffa8a8a8),
                            fontSize: 10

                        ),

                        hoverColor: Color(0xff00685c)
                    ),
                    keyboardType: TextInputType.text,
                    onFieldSubmitted: (value) {
                      setState(() {
                        desc = value;
                      });
                    },
                    validator: (value) {
                      if (value!.isEmpty ) {
                        return 'Invalid desc!';
                      }
                      return null;
                    },
                  ),
              ),


            ],
          ),
        ),
      floatingActionButton: ElevatedButton(
        onPressed: () async {
          // Action to be performed on button press
          // Navigator.push(context, MaterialPageRoute (
          //   builder: (BuildContext context) =>  PickAddress(),
          // ),);
          final success = await Authenticateservice().ResetPassword(Username: myController1.text, Email: myController1.text);

  if (success) {
    showOtpDialog(context, myController1.text);
  } else {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Failed to send OTP")),
    );
  }
        },
        style: ElevatedButton.styleFrom(
          foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
          elevation: 5, // Elevation (shadow)
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(3.0), // Rounded corners
          ),
          padding: EdgeInsets.symmetric(horizontal: 60, vertical: 11), // Button padding
        ),
        child: Text('Send OTP' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w600),), // Button text
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,

    );
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar-15 ,bottom: 5),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Reset Password' , style: GoogleFonts.lexend(fontSize: 18 , fontWeight: FontWeight.w500),),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Colors.white12,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.contain,
            ),
          ),
        ),
      ),
    );
  }
}

void showOtpDialog(BuildContext context, String email) {
  final TextEditingController otpController = TextEditingController();

  final TextEditingController myController2 = TextEditingController();
  final TextEditingController myController3 = TextEditingController();
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (_) {
      return AlertDialog(
        title: Text("Enter OTP"),
        content:Column(
          mainAxisSize: MainAxisSize.min, // To keep the dialog compact
          children: [
            Text("Code sent to your email/phone"),
            SizedBox(height: 20),
            OtpTextField(
              fieldWidth: 46,
              numberOfFields: 4, // Number of OTP digits
              borderColor: Color.fromARGB(245, 38, 82, 12),
              disabledBorderColor: Color.fromARGB(245, 38, 82, 12),
              enabledBorderColor: Color.fromARGB(245, 38, 82, 12),
              focusedBorderColor: Color.fromARGB(245, 38, 82, 12),
              showFieldAsBox: true, // Use boxes for a clean look
              autoFocus: true,
              onCodeChanged: (String code) {
                // Handle validation as each code is entered
              },
              onSubmit: (String verificationCode) {
                // Runs when all fields are filled
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Code entered: $verificationCode')),
                );

                otpController.text = verificationCode;
                // Navigator.of(context).pop(); // Dismiss the dialog
              },
            ),
            SizedBox(height: 10),

              // New Password
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: TextField(
                  controller: myController2,
                  obscureText: false,
                   decoration:  InputDecoration(
                        // filled:true,
                          // labelText: 'New Password',
                          label: Text('New Password' , style: TextStyle(fontSize: 13),),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Color(0xffa8a8a8),
                              width: 1.8,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            // borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide(
                              color: Color(0xff00685c),
                              width: 1.4,
                            ),
                          ),
                          labelStyle: TextStyle(
                              color: Color(0xffa8a8a8),
                              fontSize: 10
                
                          ),
                
                          hoverColor: Color(0xff00685c)
                      ),
                      keyboardType: TextInputType.text,
                ),
              ),

              SizedBox(height: 10),

              // Confirm Password
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: TextField(
                  controller: myController3,
                  obscureText: false,
                   decoration:  InputDecoration(
                          // filled:true,
                            // labelText: 'New Password',
                            label: Text('Confirm Password' , style: TextStyle(fontSize: 13),),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                color: Color(0xffa8a8a8),
                                width: 1.8,
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              // borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(
                                color: Color(0xff00685c),
                                width: 1.4,
                              ),
                            ),
                            labelStyle: TextStyle(
                                color: Color(0xffa8a8a8),
                                fontSize: 10
                  
                            ),
                  
                            hoverColor: Color(0xff00685c)
                        ),
                        keyboardType: TextInputType.text,
                ),
              ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel", style: TextStyle(color: Color.fromARGB(245, 38, 82, 12)),),
          ),
          ElevatedButton(
            onPressed: () async {
              final otp = otpController.text.trim();

              if (otp.length != 4) return;

              if (myController2.text != myController3.text){
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Password not matched")),
                );
              }else{

              final verified = 
                  await Authenticateservice().VerifyOTP(Otp: otpController.text, Password: myController2.text);

              if (verified) {
                Navigator.pop(context); // close dialog

                Navigator.pop(context);

                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Password Reset Successfully")),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Invalid OTP")),
                );
              }
              }
            },
            child: Text("Verify"),
          ),
        ],
      );
    },
  );
}
