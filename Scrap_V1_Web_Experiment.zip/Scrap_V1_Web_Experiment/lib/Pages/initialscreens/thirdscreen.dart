import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:scrap_app_v2/Pages/initialscreens/fourthscreen.dart';
import 'package:scrap_app_v2/Pages/initialscreens/secondscreen.dart';
class ThirdScreen extends StatelessWidget {
  const ThirdScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(padding: EdgeInsets.only(top: 20)),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [

                  Padding(
                    padding: const EdgeInsets.only(top: 20.0 , left: 5),
                    child: Column(
                      children: [
                        Image.asset('assets/inithome/init3.png'),
                      ],
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text('Pickup persons will arrive at your home' , style: GoogleFonts.lexend(fontSize: 26 ,fontWeight: FontWeight.w500) , ),
                    SizedBox(height: 20,),
                    Text('Our pickup executives will call you 1 hour before coming. They will bring on electronic machine to weigh each scrap item seperately.' , style: GoogleFonts.poppins(fontSize: 15 ,color: const Color(0xFF8D8D8D) , fontWeight: FontWeight.normal) , ),
                  ],
                ),
              ),
              SizedBox(height: 100,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  SizedBox(width: 10,),
                  Padding(
                    padding: const EdgeInsets.all(0.0),
                    child: Row(
                      children: [
                        InkWell(
                          onTap: (){

                          },
                          child: Container(
                            width: 17,
                            height: 17,
                            decoration: BoxDecoration(
                              color: Color(0xffccebe8),
                              borderRadius: BorderRadius.all(Radius.circular(25)),
                            ),
                          ),
                        ),                        SizedBox(width: 10,),

                        InkWell(
                          onTap: (){

                          },
                          child: Container(
                            width: 17,
                            height: 17,
                            decoration: BoxDecoration(
                              color: Color(0xffccebe8),
                              borderRadius: BorderRadius.all(Radius.circular(25)),
                            ),
                          ),
                        ),                        SizedBox(width: 10,),

                        InkWell(
                          onTap: (){

                          },
                          child: Container(
                            width: 25,
                            height: 25,
                            decoration: BoxDecoration(
                              color: Color(0xff00685c),
                              borderRadius: BorderRadius.all(Radius.circular(25)),
                            ),
                          ),
                        ),
                        SizedBox(width: 10,),

                        InkWell(
                          onTap: (){

                          },
                          child: Container(
                            width: 17,
                            height: 17,
                            decoration: BoxDecoration(
                              color: Color(0xffccebe8),
                              borderRadius: BorderRadius.all(Radius.circular(25)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(0),
                    child: InkWell(
                      onTap: (){
                        Navigator.push(
                          context,
                          PageRouteBuilder(
                            pageBuilder: (context, animation, secondaryAnimation) {
                              return FourthScreen();
                            },
                            transitionsBuilder: (context, animation, secondaryAnimation, child) {
                              const begin = Offset(2.0, 0.0);
                              const end = Offset(0.0, 0.0);
                              var curve = Curves.easeInOut;
                              var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
                              var offsetAnimation = animation.drive(tween);
                              return SlideTransition(position: offsetAnimation, child: child);
                            },
                          ),
                        );
                      },
                      child: Row(
                        children: [
                          Text('Next' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w500),),
                          Icon(Icons.arrow_right_alt , size: 30,color: Colors.black,)
                        ],
                      ),
                    ),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
