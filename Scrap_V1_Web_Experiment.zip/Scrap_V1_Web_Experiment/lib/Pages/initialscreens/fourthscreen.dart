import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:scrap_app_v2/Pages/Authenticate/Authenticate.dart';
import 'package:scrap_app_v2/Pages/MainHome.dart';
import 'package:scrap_app_v2/Pages/initialscreens/secondscreen.dart';
class FourthScreen extends StatelessWidget {
  const FourthScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(padding: EdgeInsets.only(top: 20)),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(padding: EdgeInsets.all(5)),
                  Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      children: [
                        Image.asset('assets/inithome/init4.png'),
                      ],
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text('Select scrap items for selling' , style: GoogleFonts.lexend(fontSize: 26 ,fontWeight: FontWeight.w500) , ),
                    SizedBox(height: 20,),
                    Text('You will receive the amount either through your UPI ID or in cash by hand \n\n The rates are non-negotiable, please check the rates before booking a pickup request.' , style: GoogleFonts.poppins(fontSize: 15 ,color: const Color(0xFF8D8D8D) , fontWeight: FontWeight.normal) , ),
                  ],
                ),
              ),
               SizedBox(height: 20,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      // Action to be performed on button press
                      Navigator.pushAndRemoveUntil<dynamic>(
                            context,
                            MaterialPageRoute<dynamic>(
                              builder: (BuildContext context) => Authenticate(),
                            ),
                                (route) => false,//if you want to disable back feature set to false
                          );
                    },
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
                      elevation: 5, // Elevation (shadow)
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(3.0), // Rounded corners
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 100, vertical: 11), // Button padding
                    ),
                    child: Text('Get Started' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w600),), // Button text
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
