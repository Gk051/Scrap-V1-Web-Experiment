

import 'package:flutter/cupertino.dart';
import 'package:scrap_app_v2/Components/LoadingOrError.dart';
import 'package:scrap_app_v2/Services/http_with_timeout.dart' show friendlyError;
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show debugPrint;
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/Components/Navbar.dart';
import 'package:scrap_app_v2/NavMenus/Profile.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/AddAddress.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/screen1.dart';
import 'package:scrap_app_v2/Pages/Ratelist/RateList.dart';
import 'package:scrap_app_v2/Services/DataService.dart';
import 'package:scrap_app_v2/Services/ProviderService.dart';

import '../Services/LoaderService.dart';

class CategoryHome extends StatefulWidget {
  const CategoryHome({Key? key , required this.User_id}) : super(key: key);
  final int User_id;
  @override
  State<CategoryHome> createState() => _CategoryHomeState();
}

class _CategoryHomeState extends State<CategoryHome> {

  int _currentIndex = 0;
  int? CategorydataIndex;
  int? user_id;
  List<dynamic> Categorydata = [
    {"title": "Option 1" , "category_name":"" , "description":""},
  ];
  Map<dynamic,dynamic> Profiledata = {};
  // WEB EXPERIMENT: a failed request now shows a message + "Try again" button
  // instead of leaving the loader on forever.
  String? _loadError;

  dynamic getCategory() async{
    final loader = context.read<LoaderProvider>();
    try {
      final data = await Dataservice().GetCategory();
      if (data is! List) {
        throw const FormatException('Unexpected categories response');
      }
      Categorydata = data;
      _loadError = null;
    } catch (e) {
      _loadError = friendlyError(e);
    }
    loader.hideLoader();
    if (!mounted) return;
    setState(() {

    });
  }
  dynamic getProfileDetails()async{
    try {
      final data = await Dataservice().GetProfileDetails(id: widget.User_id);
      if (data is! Map) {
        throw const FormatException('Unexpected profile response');
      }
      Profiledata = data;
      if (!mounted) return;
      context.read<MainProvider>().updateUserData(data: Profiledata);
      final address = Profiledata['address'];
      context.read<MainProvider>().updateAddress(address: address is List ? address : <dynamic>[]);
    } catch (e) {
      // Profile details are secondary; the category list decides whether the
      // screen is usable. Keep going with an empty profile.
      debugPrint('CategoryHome: could not load profile: $e');
    }
    if (!mounted) return;
    setState(() {

    });
  }

  void _reload() {
    setState(() {
      _loadError = null;
    });
    context.read<LoaderProvider>().showLoader();
    getCategory();
    getProfileDetails();
  }
  final List<Widget> _pages = [
    SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 25.0 , top: 20),
            child: Text('Hey , User1' , style: GoogleFonts.poppins(fontSize: 20 , color: Color(0xff585858)),),
          ),

          Padding(
            padding: const EdgeInsets.only(left: 25.0 , top: 20),
            child: Text('What would you like to sell ?' , style: GoogleFonts.lexend(fontSize: 26 ,fontWeight: FontWeight.w600)),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 25.0 , top: 20),
            child: Wrap(
              spacing: 15,
              runSpacing: 15,
              children: [
                Container(
                  width: 103,
                  child: Column(

                    children: [
                      Container(


                        decoration: BoxDecoration(
                            border: Border.all(
                              color: Color(0xff8a8a8a), // Border color
                              width: 2.5, // Border width
                            ),
                            borderRadius: BorderRadius.circular(5)
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [

                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [

                                Padding(
                                  padding: const EdgeInsets.only(top: 4.0 , right: 8),
                                  child: Container(
                                    width: 18,
                                    height: 18,
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                          color: Color(0xff8a8a8a), // Border color
                                          width: 1.5, // Border width
                                        ),
                                        borderRadius: BorderRadius.circular(16)
                                    ),
                                    child: Icon(Icons.check , size: 14, color: Color(0xff8a8a8a),),
                                  ),
                                )
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 0.0 , left: 0),
                              child: Image.asset('assets/inithome/cat1.png'),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Text('Plastic' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500),),
                            )
                          ],
                        ),
                      ),
                      SizedBox(height: 4,),
                      Text('Newspapers, Cartoons, Books' , softWrap: true, style: GoogleFonts.poppins(fontSize: 10 , color: Color(0xff8d8d8d) , fontWeight: FontWeight.w500),)
                    ],
                  ),
                ),
                Container(
                  width: 103,
                  child: Column(

                    children: [
                      Container(


                        decoration: BoxDecoration(
                            border: Border.all(
                              color: Color(0xff8a8a8a), // Border color
                              width: 2.5, // Border width
                            ),
                            borderRadius: BorderRadius.circular(5)
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [

                            Row(

                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [

                                Padding(
                                  padding: const EdgeInsets.only(top: 4.0 , right: 8),
                                  child: Container(
                                    width: 18,
                                    height: 18,
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                          color: Color(0xff8a8a8a), // Border color
                                          width: 1.5, // Border width
                                        ),
                                        borderRadius: BorderRadius.circular(16)
                                    ),
                                    child: Icon(Icons.check , size: 14, color: Color(0xff8a8a8a),),
                                  ),
                                )
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 0.0 , left: 0),
                              child: Image.asset('assets/inithome/cat1.png'),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Text('Plastic' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500),),
                            )
                          ],
                        ),
                      ),
                      SizedBox(height: 4,),
                      Text('Newspapers, Cartoons, Books' , softWrap: true, style: GoogleFonts.poppins(fontSize: 10 , color: Color(0xff8d8d8d) , fontWeight: FontWeight.w500),)
                    ],
                  ),
                ),
                Container(
                  width: 103,
                  child: Column(

                    children: [
                      Container(


                        decoration: BoxDecoration(
                            border: Border.all(
                              color: Color(0xff8a8a8a), // Border color
                              width: 2.5, // Border width
                            ),
                            borderRadius: BorderRadius.circular(5)
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [

                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [

                                Padding(
                                  padding: const EdgeInsets.only(top: 4.0 , right: 8),
                                  child: Container(
                                    width: 18,
                                    height: 18,
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                          color: Color(0xff8a8a8a), // Border color
                                          width: 1.5, // Border width
                                        ),
                                        borderRadius: BorderRadius.circular(16)
                                    ),
                                    child: Icon(Icons.check , size: 14, color: Color(0xff8a8a8a),),
                                  ),
                                )
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 0.0 , left: 0),
                              child: Image.asset('assets/inithome/cat1.png'),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Text('Plastic' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500),),
                            )
                          ],
                        ),
                      ),
                      SizedBox(height: 4,),
                      Text('Newspapers, Cartoons, Books' , softWrap: true, style: GoogleFonts.poppins(fontSize: 10 , color: Color(0xff8d8d8d) , fontWeight: FontWeight.w500),)
                    ],
                  ),
                ),
                Container(
                  width: 103,
                  child: Column(

                    children: [
                      Container(


                        decoration: BoxDecoration(
                            border: Border.all(
                              color: Color(0xff8a8a8a), // Border color
                              width: 2.5, // Border width
                            ),
                            borderRadius: BorderRadius.circular(5)
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [

                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [

                                Padding(
                                  padding: const EdgeInsets.only(top: 4.0 , right: 8),
                                  child: Container(
                                    width: 18,
                                    height: 18,
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                          color: Color(0xff8a8a8a), // Border color
                                          width: 1.5, // Border width
                                        ),
                                        borderRadius: BorderRadius.circular(16)
                                    ),
                                    child: Icon(Icons.check , size: 14, color: Color(0xff8a8a8a),),
                                  ),
                                )
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 0.0 , left: 0),
                              child: Image.asset('assets/inithome/cat1.png'),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Text('Plastic' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500),),
                            )
                          ],
                        ),
                      ),
                      SizedBox(height: 4,),
                      Text('Newspapers, Cartoons, Books' , softWrap: true, style: GoogleFonts.poppins(fontSize: 10 , color: Color(0xff8d8d8d) , fontWeight: FontWeight.w500),)
                    ],
                  ),
                ),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 5.0 , top: 50 , right: 5),
                child: ElevatedButton(
                  onPressed: () {
                    // Action to be performed on button press

                  },
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
                    elevation: 5, // Elevation (shadow)
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(3.0), // Rounded corners
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 60, vertical: 11), // Button padding
                  ),
                  child: Text('Raise Pickup Request' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w600),), // Button text
                ),
              ),
            ],
          ),
        ],
      ),
    ),
    SingleChildScrollView(

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 25.0 , top: 20),
            child: Text('Today\'s scrap price list ', style: GoogleFonts.lexend(fontSize: 25 ,fontWeight: FontWeight.w600)),
          ),
          Padding(
          padding: const EdgeInsets.only(left: 28.0 , top: 20 ),
          child: Text('Price may fluctuate because of the recycling industry' , style: GoogleFonts.poppins(fontSize: 12 , color: Color(0xff585858)),),
        ),
          Padding(
            padding: const EdgeInsets.only(left: 28.0 , top: 20 ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Paper' , style: GoogleFonts.poppins(fontSize:15 ),),
                SizedBox(height: 5,),
                Wrap(
                  spacing: 15,
                  runSpacing: 15,
                  children: [
                    Container(
                      width: 113,
                      decoration: BoxDecoration(
                          border: Border.all(
                            color: Color(0xff8a8a8a), // Border color
                            width: 2.5, // Border width
                          ),
                          borderRadius: BorderRadius.circular(5)
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [

                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text('Office Paper' , style: GoogleFonts.poppins(fontSize: 12 , fontWeight: FontWeight.w500),),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text('(A3/A4)' , style: GoogleFonts.poppins(fontSize: 8 , color: Color(0xff585858)),),
                          ),
                          Container(
                              width: double.infinity,
                              height: 30,
                              decoration: BoxDecoration(
                                color: Color(0xff408e85),

                              ),
                              child:Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('₹12/kg' , style: GoogleFonts.poppins(fontSize: 10 , color: Colors.white),)
                                ],
                              )
                          )
                        ],
                      ),
                    ),
                    Container(
                      width: 113,
                      decoration: BoxDecoration(
                          border: Border.all(
                            color: Color(0xff8a8a8a), // Border color
                            width: 2.5, // Border width
                          ),
                          borderRadius: BorderRadius.circular(5)
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [

                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text('Office Paper' , style: GoogleFonts.poppins(fontSize: 12 , fontWeight: FontWeight.w500),),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text('(A3/A4)' , style: GoogleFonts.poppins(fontSize: 8 , color: Color(0xff585858)),),
                          ),
                          Container(
                              width: double.infinity,
                              height: 30,
                              decoration: BoxDecoration(
                                color: Color(0xff408e85),

                              ),
                              child:Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('₹12/kg' , style: GoogleFonts.poppins(fontSize: 10 , color: Colors.white),)
                                ],
                              )
                          )
                        ],
                      ),
                    ),
                    Container(
                      width: 113,
                      decoration: BoxDecoration(
                          border: Border.all(
                            color: Color(0xff8a8a8a), // Border color
                            width: 2.5, // Border width
                          ),
                          borderRadius: BorderRadius.circular(5)
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [

                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text('Office Paper' , style: GoogleFonts.poppins(fontSize: 12 , fontWeight: FontWeight.w500),),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text('(A3/A4)' , style: GoogleFonts.poppins(fontSize: 8 , color: Color(0xff585858)),),
                          ),
                          Container(
                              width: double.infinity,
                              height: 30,
                              decoration: BoxDecoration(
                                color: Color(0xff408e85),

                              ),
                              child:Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('₹12/kg' , style: GoogleFonts.poppins(fontSize: 10 , color: Colors.white),)
                                ],
                              )
                          )
                        ],
                      ),
                    ),
                    Container(
                      width: 113,
                      decoration: BoxDecoration(
                          border: Border.all(
                            color: Color(0xff8a8a8a), // Border color
                            width: 2.5, // Border width
                          ),
                          borderRadius: BorderRadius.circular(5)
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [

                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text('Office Paper' , style: GoogleFonts.poppins(fontSize: 12 , fontWeight: FontWeight.w500),),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text('(A3/A4)' , style: GoogleFonts.poppins(fontSize: 8 , color: Color(0xff585858)),),
                          ),
                          Container(
                              width: double.infinity,
                              height: 30,
                              decoration: BoxDecoration(
                                color: Color(0xff408e85),

                              ),
                              child:Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('₹12/kg' , style: GoogleFonts.poppins(fontSize: 10 , color: Colors.white),)
                                ],
                              )
                          )
                        ],
                      ),
                    ),
                  ],
                ),

                ],
            ),
          )



        ],
      ),
    )
  ];
  @override
  void initState() {
    super.initState();

    context.read<LoaderProvider>().showLoader();
    user_id = widget.User_id;
    getCategory();
    getProfileDetails();
    // Initialize the AnimationController

  }

  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      extendBodyBehindAppBar: true,
      drawer: Navbar(),
       appBar: CustomAppBar(),
       body: (context.watch<LoaderProvider>().isLoading || (_loadError != null && _currentIndex == 0))?LoadingOrError(error: _currentIndex == 0 ? _loadError : null, onRetry: _reload):[
         SingleChildScrollView(
           child: Column(
             crossAxisAlignment: CrossAxisAlignment.start,
             children: [
                SizedBox(height: 125,),
               Padding(
                 padding: const EdgeInsets.only(left: 25.0 , top: 20),
                 child: Text('Hey , ${Profiledata['user_name'] ?? 'User 1'}' , style: GoogleFonts.poppins(fontSize: 20 , color: Color(0xff585858)),),
               ),

               Padding(
                 padding: const EdgeInsets.only(left: 25.0 , top: 20),
                 child: Text('What would you like to sell ?' , style: GoogleFonts.lexend(fontSize: 26 ,fontWeight: FontWeight.w600)),
               ),
               Padding(
                 padding: const EdgeInsets.only(left: 25.0 , top: 20),
                 child: Wrap(
                   spacing: 15,
                   runSpacing: 15,
                   children: Categorydata.map((item){
                     int index = Categorydata.indexOf(item);
                     return GestureDetector(
                       onTap: (){
                         setState(() {
                           CategorydataIndex = index;
                         });
                       },
                       child: Container(
                         width: 103,
                         child: Column(
                           children: [
                             Container(
                               decoration: BoxDecoration(
                                   border: Border.all(
                                     color: CategorydataIndex == index ?Color(0xff00988a):Color(0xff8a8a8a), // Border color
                                     width: 2.5, // Border width
                                   ),
                                   borderRadius: BorderRadius.circular(5),
                                   color:CategorydataIndex == index ? Color(0xff00988a).withOpacity(0.2):Colors.transparent

                               ),
                               child: Column(
                                 mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                 children: [

                                   Row(
                                     mainAxisAlignment: MainAxisAlignment.end,
                                     children: [

                                       Padding(
                                         padding: const EdgeInsets.only(top: 4.0 , right: 8),
                                         child: Icon(CategorydataIndex == index ?Icons.check_circle:Icons.check_circle_outline , size: 22, color: CategorydataIndex == index ?Color(0xff00988a):Color(0xff8a8a8a),),
                                       )
                                     ],
                                   ),
                                   Padding(
                                     padding: const EdgeInsets.only(top: 0.0 , left: 0),
                                     child: Image.asset('assets/inithome/cat1.png'),
                                   ),
                                   Padding(
                                     padding: const EdgeInsets.all(5.0),
                                     child: Text(item['category_name'] , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500),),
                                   )
                                 ],
                               ),
                             ),
                             SizedBox(height: 4,),
                             Row(
                               children: [
                                 Padding(
                                   padding: const EdgeInsets.symmetric(horizontal: 2.0 , vertical: 1),
                                   child: Text(item['description'] , softWrap: true, style: GoogleFonts.poppins(fontSize: 13 , color: Color(0xff8d8d8d) , fontWeight: FontWeight.w500),maxLines: 3,textAlign: TextAlign.left,),
                                 ),
                               ],
                             )
                           ],
                         ),
                       ),
                     );
                   }).toList(),
                 ),
               ),

             ],
           ),
         ),
         Ratelist()
       ][_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        elevation: 0,
        type:BottomNavigationBarType.fixed,
        selectedItemColor: Color(0xff184d47),
        unselectedItemColor: Color(0xff184d47),
        selectedLabelStyle: GoogleFonts.poppins(fontWeight: FontWeight.w600),
        unselectedLabelStyle: GoogleFonts.poppins(),
        selectedFontSize: 18,
        unselectedFontSize: 18,
        items: [
          BottomNavigationBarItem(

            icon: _currentIndex == 0?Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: EdgeInsets.zero,
                  width: double.infinity,
                  height: 5,
                  color: Color(0xff184d47),
                ),
                SizedBox(height: 8,),
                Image.asset('assets/inithome/icon-bnavbar.png'),
              ],
            ):Image.asset('assets/inithome/icon-bnavbar.png'),
            label: 'Sell Scrap',
          ),
          BottomNavigationBarItem(
            icon: _currentIndex == 1?Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: EdgeInsets.zero,
                  width: double.infinity,
                  height: 5,
                  color: Color(0xff184d47),
                ),
                SizedBox(height: 8,),
                Image.asset('assets/inithome/icon-bnavbar2.png'),
              ],
            ):Image.asset('assets/inithome/icon-bnavbar2.png'),
            label: 'Rate List',
          ),

        ],
      ),
      floatingActionButtonAnimator: CustomScalingAnimator(),
      floatingActionButton: _currentIndex == 0
          ?Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Container(
          width: MediaQuery.of(context).size.width,
          child: ElevatedButton(

            onPressed: CategorydataIndex != null?() {
              // Action to be performed on button press
              Navigator.push(context, MaterialPageRoute (
                builder: (BuildContext context) =>  RaiseScreen1(category_id: Categorydata[CategorydataIndex!]['id'],category_name: Categorydata[CategorydataIndex!]['category_name'],),
              ),);
            }:null,

            style: ElevatedButton.styleFrom(
              disabledBackgroundColor: Color(0xff00685c).withOpacity(0.4),
              disabledForegroundColor: Colors.white,
              foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
              elevation: 5, // Elevation (shadow)
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(3.0), // Rounded corners
              ),
              padding: EdgeInsets.symmetric( vertical: 11), // Button padding
            ),
            child: Text('Raise Pickup Request' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w600),), // Button text
          ),
        ),
      ):null,
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}
void _showBottomModal(BuildContext context) {
  List<dynamic> addresses = context.read<MainProvider>().Address;
  // int selectedId = context.watch<MainProvider>().selectedAddressindex;
  showGeneralDialog(
    context: context,
    barrierLabel: "Barrier",
    barrierDismissible: true,
    barrierColor: Colors.black.withOpacity(0.5),
    transitionDuration: Duration(milliseconds: 500),
    pageBuilder: (_, __, ___) {
      return Align(
        alignment: Alignment.topCenter,
        child: Container(
          constraints: BoxConstraints(
            maxHeight: 540
          ),
          child: Material(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(top: 48.0 , left: 20 , right: 20 , bottom: 15),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Select Pickup\naddress' , style: GoogleFonts.lexend(fontSize: 26 , fontWeight: FontWeight.w600 , color: Color(0xff151111)),softWrap: true,),
                          InkWell(
                              onTap: (){
                                Navigator.pop(context);
                              },
                              child: Icon(Icons.keyboard_arrow_up , size: 50,))
                        ],
                      ),
                      // Padding(
                      //     padding: const EdgeInsets.only( top: 20 , ),
                      //     child: Container(
                      //       decoration: BoxDecoration(
                      //         border: Border.all(color: Color(0xff00685c) , width: 1),
                      //         borderRadius: BorderRadius.circular(3),
                      //         color: Color(0xffccebe8),
                      //       ),
                      //       width: double.infinity,
                      //       child: Padding(
                      //         padding: const EdgeInsets.all(15.0),
                      //         child: Row(
                      //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      //           crossAxisAlignment: CrossAxisAlignment.center,
                      //           children: [
                      //             Column(
                      //               crossAxisAlignment: CrossAxisAlignment.start,
                      //               children: [
                      //                 Text('Work' , style: GoogleFonts.poppins(fontSize: 15 , fontWeight: FontWeight.w500),),
                      //                 Text('12/5, opp to Govt-College , Palladam' , style: GoogleFonts.poppins(fontSize: 11 ),),
                      //
                      //               ],
                      //             ),
                      //
                      //           ],
                      //         ),
                      //       ),
                      //     )
                      // ),
            
                      SingleChildScrollView(
                        child: Container(
                          decoration: BoxDecoration(
                            // color: Colors.red
                          ),
                          constraints: BoxConstraints(
                            minHeight: 0,
                            maxHeight: 250
                          ),
                          child: addresses.length>0?ListView.builder(
                            itemCount: context.watch<MainProvider>().Address.length,
                            itemBuilder: (context, index) {
                              final address = addresses[index];
                              return Padding(
                                padding: const EdgeInsets.only( top: 20  ),
                                child:InkWell(
                                onTap: (){
                                    
                                    
                                    context.read<MainProvider>().updateAddressIndex(index: index);
                                    
                                },
                                child:  Container(
                                      decoration: BoxDecoration(
                                        border: Border.all(color: context.watch<MainProvider>().selectedAddressindex == index ?Color(0xff00685c):Color(0xff8a8a8a) , width: 1),
                                        borderRadius: BorderRadius.circular(3),
                                        color: context.watch<MainProvider>().selectedAddressindex == index ?Color(0xffccebe8):Colors.transparent,
                                      ),
                                      width: double.infinity,
                                      child: Padding(
                                        padding: const EdgeInsets.all(12.0),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Expanded(
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Text(address['type'].toString() , style: GoogleFonts.poppins(fontSize: 16 , fontWeight: FontWeight.w500),),
                                                  Text(address['address'] , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w400 ),overflow: TextOverflow.ellipsis,maxLines: 1,),
                                                                                  
                                                ],
                                              ),
                                            ),
                                            // IconButton(onPressed: (){}, icon: Icon(Icons.delete , size: 30 , color: Color(0xff00685c),))
                                          ],
                                        ),
                                      ),
                                    )
                                ),
                              );
                            },
                          ):Center(
                            child: Text('No Address Found \n try add address or refresh' , style: GoogleFonts.poppins(fontSize: 16 , fontWeight: FontWeight.w500),textAlign: TextAlign.center,),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: 1,
                              width: 100,
                              color: Color(0xff8a8a8a),
                            ),
                            SizedBox(width: 10,),
                            Text('OR' , style: GoogleFonts.lexend(fontSize: 10,),),
                            SizedBox(width: 10,),
                            Container(
                              height: 1,
                              width: 100,
                              color: Color(0xff8a8a8a),
                            ),
                          ],
                        ),
                      ),
                      TextButton(
                        onPressed: (){
                          Navigator.push(context, MaterialPageRoute (
                            builder: (BuildContext context) =>  AddAddress(),
                          ),);
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.add_circle_outline , size: 25, color: Color(0xff00685c),),
                            SizedBox(width: 10,),
                            Text('Add Address' , style: GoogleFonts.poppins(fontSize: 15 , color: Color(0xff00685c),fontWeight: FontWeight.w600)),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
            
              ],
            ),
          ),
          margin: EdgeInsets.only(bottom: 0, left: 0, right: 0),
        ),
      );
    },
    transitionBuilder: (_, anim, __, child) {
      return SlideTransition(
        position: Tween(begin: Offset(0, -1), end: Offset(0, 0))
            .animate(anim),
        child: child,
      );
    },
  );
}
class CustomAppBar extends StatefulWidget implements PreferredSizeWidget {
  @override
  State<CustomAppBar> createState() => _CustomAppBarState();

  @override
  // TODO: implement preferredSize
  Size get preferredSize => Size.fromHeight(100);
}

class _CustomAppBarState extends State<CustomAppBar> {
  bool isOpen = false;

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    var scaffoldKey = Navbar().key;
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    print('padding ${statusbar}');
    List<dynamic> addresses = context.read<MainProvider>().Address;
    return Padding(
      padding: EdgeInsets.only(top: statusbar>0?statusbar-12:0,bottom: 8),
      child: AppBar(
        title: Row(

          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [

            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('Pickup Location - ${context.watch<MainProvider>().selectedAddressindex>=0 && context.watch<MainProvider>().Address.length>0?context.watch<MainProvider>().Address[context.watch<MainProvider>().selectedAddressindex]['type'] : 'Shop'}' , style: GoogleFonts.lexend(fontSize: 15 , fontWeight: FontWeight.w500),),
                  ],
                ),
                SizedBox(height: 5,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('Add Address' , style: GoogleFonts.lexend(fontSize: 10 , fontWeight: FontWeight.normal),),
                  ],
                ),

              ],
            ),
            InkWell(
              onTap: (){
                _showBottomModal(context , );
                setState(() {
                  isOpen = !isOpen;
                });
              },
                child: Icon(Icons.keyboard_arrow_down , size: 50,)),
          ],
        ),
        backgroundColor: Color(0xff00685C),
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30) , bottomRight: Radius.circular(30))
        ),
        flexibleSpace: Container(
          // height: 200,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.fill,
            ),
          ),
        ),

          // bottom: PreferredSize(child: isOpen? Container(color:Colors.red, height: 75):Container(),preferredSize:Size.fromHeight(isOpen? 75:0) ,),
      ),
    );
  }
}

// Custom Animator Class
class CustomScalingAnimator extends FloatingActionButtonAnimator {
  @override
  Offset getOffset({
    required Offset begin,
    required Offset end,
    required double progress,
  }) {
    // Smoothly interpolate between the start and end positions
    return Offset.lerp(begin, end, progress)!;
  }

  @override
  Animation<double> getScaleAnimation({required Animation<double> parent}) {
    // Define a scaling animation (from 0.8 to 1.0)
    return Tween<double>(begin: 1, end: 1.0).animate(
      CurvedAnimation(parent: parent, curve: Curves.easeInOutCubicEmphasized),

    );
  }

  @override
  Animation<double> getRotationAnimation({required Animation<double> parent}) {
    // No rotation: Return a constant value of 0.0
    return AlwaysStoppedAnimation(01.0);
  }
}