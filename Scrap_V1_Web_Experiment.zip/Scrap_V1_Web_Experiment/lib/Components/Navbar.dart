// import 'package:another_telephony/telephony.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/NavMenus/AboutUs.dart';
import 'package:scrap_app_v2/NavMenus/Howitworks.dart';
import 'package:scrap_app_v2/NavMenus/Profile.dart';
import 'package:scrap_app_v2/NavMenus/Requests.dart';
import 'package:scrap_app_v2/NavMenus/ShareUs.dart';
import 'package:scrap_app_v2/Pages/Authenticate/Authenticate.dart';
import 'package:scrap_app_v2/Services/http_with_timeout.dart' as http;
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:scrap_app_v2/Pages/CategoryHome.dart';
import 'package:scrap_app_v2/Services/ProviderService.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:convert';

import '../Constants/globals.dart';
import '../Services/SecureStorageServices.dart';

class Navbar extends StatefulWidget {
  const Navbar({Key? key}) : super(key: key);
  @override
  State<Navbar> createState() => _NavbarState();
}

class _NavbarState extends State<Navbar> {
  final SecureStorage _secureStorage = SecureStorage();
  late bool isAdmin;
  void initState() {
    isAdmin = false;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        // Remove padding
        padding: EdgeInsets.zero,
        children: [
          InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (BuildContext context) => Profile()));
            },
            child: UserAccountsDrawerHeader(
              accountName: Text('Welcome'),
              accountEmail: Text(
                context.read<MainProvider>().userData['user_name'].toString(),
                style: GoogleFonts.poppins(
                    fontSize: 18, fontWeight: FontWeight.w600),
              ),
              currentAccountPicture: CircleAvatar(
                child: ClipOval(
                  // child: user_info.photoURL != null ? Image.network(
                  //   user_info.photoURL.toString(),
                  //   fit: BoxFit.cover,
                  //   width: 90,
                  //   height: 90,)
                  child: Image.asset(
                    'assets/man.webp',
                    fit: BoxFit.cover,
                    width: 90,
                    height: 90,
                  ),
                ),
              ),
              decoration: const BoxDecoration(
                color: Color(0xff00685c),
                // image: DecorationImage(
                //   fit: BoxFit.fill,
                //   image: AssetImage('assets/5442673.jpg'),
                // ),
              ),
            ),
          ),
          ListTile(
              leading:
                  const Icon(Icons.home_outlined, color: Color(0xff000000)),
              title: const Text('Home',
                  style: TextStyle(color: Color(0xff000000))),
              onTap: () {
                Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                        builder: (BuildContext context) => CategoryHome(User_id: context.read<MainProvider>().user_id)), (route)=> false);

              }),
          const Divider(),
          ListTile(
              leading: const Icon(Icons.home_work_outlined,
                  color: Color(0xff000000)),
              title: const Text('Pickup request',
                  style: TextStyle(color: Color(0xff000000))),
              onTap: () async {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (BuildContext context) => PickRequest()));
                setState(() {});

                // setState(() {
                //   isCallGoogle = false;
                // });
              }),
          ListTile(
              leading: const Icon(Icons.analytics_outlined,
                  color: Color(0xff000000)),
              title: const Text('How it works',
                  style: TextStyle(color: Color(0xff000000))),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (BuildContext context) => Howitworks()));
              }
              // Navigator.pushAndRemoveUntil(
              //     context, MaterialPageRoute<dynamic>(
              //   builder: (BuildContext context) =>
              //       createClass(users: user_info),
              // ),
              //         (route) => false
              // ),
              ),
          ListTile(
            leading: const Icon(
              Icons.share,
              color: Color(0xff000000),
            ),
            title: const Text(
              'Share Us',
              style: TextStyle(color: Color(0xff000000)),
            ),
            onTap: () async {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (BuildContext context) => ShareUs()));
              setState(() {
                // isCallGoogle = true;
              });
              // await AdminService.GetFriendClassList(context: context, users: user_info);
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.contact_mail_outlined,
              color: Color(0xff000000),
            ),
            title: const Text('Profile'),
            onTap: () async {
              Navigator.push(context,
                  MaterialPageRoute(builder: (
                      BuildContext context) => Profile()));
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.info,
              color: Color(0xff000000),
            ),
            title: const Text('About Us'),
            onTap: () async {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (BuildContext context) => AboutUs()));
              setState(() {
                // isCallGoogle = true;
              });
              // await AdminService.GetClassExportList(users: user_info, context: context);
            },
          ),
          const Divider(),
          ListTile(
            title: const Text('Call Us',
                style: TextStyle(color: Color(0xff000000))),
            leading: const Icon(
              Icons.call,
              color: Color(0xff000000),
            ),
            onTap: () async {
    // WEB EXPERIMENT: browsers have no phone permission; on the web we skip it
    // and open the tel: link directly (mobile browsers start the call).
    final bool canCall = kIsWeb ? true : (await Permission.phone.request()).isGranted;
    if (canCall) {
              final String phoneNumber = '+919025847656';
              // var launchUri = Uri(
              //   scheme: 'tel',
              //   path: phoneNumber,
              // );
              var launchUri = Uri.parse("tel:9025847656");
              print(launchUri);
              // if (await canLaunchUrl(launchUri))
              try
              {
                await launchUrl(launchUri);
              } catch(e) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not launch $phoneNumber')));
                throw 'Could not launch $phoneNumber';
              }
            }
            else{
      print('Permission denied');
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Permission denied')));
    }
            },
          ),
          ListTile(
            title: const Text('Log Out',
                style: TextStyle(color: Color(0xff000000))),
            leading: const Icon(
              Icons.exit_to_app,
              color: Color(0xff000000),
            ),
            onTap: () async {
              // WEB EXPERIMENT: sign-out must work even if the server cannot be
              // reached, so a failed logout call no longer blocks clearing the session.
              try {
                await http.post(
                  Uri.parse(ApiUrls.baseUrl + 'api/logout/'),
                  headers: {"Content-Type": "application/json"},
                );
              } catch (_) {}
              await _secureStorage.deleteData('user_id');

              Navigator.pushAndRemoveUntil<dynamic>(
                context,
                MaterialPageRoute<dynamic>(
                  builder: (BuildContext context) => Authenticate(),
                ),
                (route) =>
                    false, //if you want to disable back feature set to false
              );
            },
          ),
        ],
      ),
    );
  }
}
