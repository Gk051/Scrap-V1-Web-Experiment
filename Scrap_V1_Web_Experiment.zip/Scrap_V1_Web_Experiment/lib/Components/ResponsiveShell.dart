// WEB EXPERIMENT: wraps the whole app so it behaves sensibly on any screen.
//
//  * Phones / narrow windows: the app fills the screen exactly as before.
//  * Tablets / laptops / desktops: the app is shown as a centred column of
//    limited width on a soft background instead of being stretched edge to
//    edge. Widgets that read MediaQuery width see the column width, so existing
//    screens lay out correctly inside it.
//  * System / browser text scaling is capped so layouts do not break.
//
// This is an interim layout, not a full multi-column redesign (see docs).
import 'package:flutter/material.dart';

class ResponsiveShell extends StatelessWidget {
  const ResponsiveShell({Key? key, required this.child}) : super(key: key);

  final Widget child;

  /// Widest the app column is allowed to get (logical pixels).
  static const double maxContentWidth = 560;

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final scaled = mq.copyWith(
      textScaler: mq.textScaler.clamp(minScaleFactor: 0.8, maxScaleFactor: 1.3),
    );

    if (mq.size.width <= maxContentWidth) {
      return MediaQuery(data: scaled, child: child);
    }

    return ColoredBox(
      color: const Color(0xffe9efee),
      child: Center(
        child: SizedBox(
          width: maxContentWidth,
          child: DecoratedBox(
            decoration: const BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Color(0x22000000),
                  blurRadius: 24,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: ClipRect(
              child: MediaQuery(
                data: scaled.copyWith(
                  size: Size(maxContentWidth, mq.size.height),
                ),
                child: child,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
