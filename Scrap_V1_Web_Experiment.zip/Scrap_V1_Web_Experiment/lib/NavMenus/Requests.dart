

import 'package:flutter/cupertino.dart';
import 'package:scrap_app_v2/Components/LoadingOrError.dart';
import 'package:scrap_app_v2/Services/http_with_timeout.dart' show friendlyError;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/NavMenus/RequestStatus.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/PickupConfirm.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/PickupDetails.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/screen3.dart';
import 'package:scrap_app_v2/Services/DataService.dart';
import 'package:scrap_app_v2/Services/ProviderService.dart';

import '../Services/LoaderService.dart';

class PickRequest extends StatefulWidget {
  const PickRequest({Key? key}) : super(key: key);

  @override
  State<PickRequest> createState() => _PickRequestState();
}

class _PickRequestState extends State<PickRequest> {
  List<dynamic> Requests = [];
  // WEB EXPERIMENT: failed request -> message + "Try again" instead of endless loader.
  String? _loadError;

  void getRequests()async{
    final loader = context.read<LoaderProvider>();
    loader.showLoader();
    try {
      final data = await Dataservice().GetAllOrderDetails(id: context.read<MainProvider>().user_id);
      if (data is! List) {
        throw const FormatException('Unexpected requests response');
      }
      Requests = data;
      if (!mounted) return;
      context.read<MainProvider>().updateRequests(data: Requests);
      _loadError = null;
    } catch (e) {
      _loadError = friendlyError(e);
    }
    loader.hideLoader();
    if (!mounted) return;
    setState(() {
    });
  }

  void _reload() {
    setState(() {
      _loadError = null;
    });
    getRequests();
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getRequests();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: CustomAppBar(),
      body:
      (context.watch<LoaderProvider>().isLoading || _loadError != null)?LoadingOrError(error: _loadError, onRetry: _reload):SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 125,),

            Padding(
              padding: const EdgeInsets.only(left: 25.0 , top: 20),
              child: Text('Your Scrap pickups' , style: GoogleFonts.lexend(fontSize: 26 ,fontWeight: FontWeight.w600)),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 25.0 , top: 20),
              child: Text('Completed and cancelled' , style: GoogleFonts.poppins(fontSize: 14 ,fontWeight: FontWeight.w500,)),
            ),
            Column(
              children: context.watch<MainProvider>().Requests.isEmpty?[
                Padding(
                  padding: const EdgeInsets.only(top: 20 , left: 25),
                  child: Text('No Requests Found' , style: GoogleFonts.poppins(fontSize: 23,fontWeight: FontWeight.w500),),
                )
              ]:context.watch<MainProvider>().Requests.map((item){
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: InkWell(
                    onTap: (){
                      Navigator.push(context,
                          MaterialPageRoute(builder: (
                              BuildContext context) => PickStatus(OrderDetails: item,))
                      );
                    },
                    child: Card(
                      elevation:1,
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            item['order_status']=="pending"?Icon(Icons.update , size: 40, color: Color(0xfffa9f0b),):item['order_status']=="picked"?Image.asset('assets/inithome/right.png', width: 35,height: 35,):item['order_status']=="accepted"?Icon(Icons.edit_calendar_rounded , size: 40, color: Colors.green,):Image.asset('assets/inithome/wrong.png', width: 35,height: 35,),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(item['items'][0]['item_name'] , style: GoogleFonts.poppins(fontSize: 18 ,color: Color(0xff373737), fontWeight: FontWeight.w500),),
                                Text(DateFormat('dd MMMM yyyy').format(DateTime.parse(item['pick_up_date'])) , style: GoogleFonts.poppins(fontSize: 14 , color: Color(0xff8a8a8a) , fontWeight: FontWeight.w500),),

                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),

            // Padding(
            //   padding: const EdgeInsets.all(8.0),
            //   child: Card(
            //     elevation:1,
            //     child: Padding(
            //       padding: const EdgeInsets.all(20.0),
            //       child: Row(
            //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //         crossAxisAlignment: CrossAxisAlignment.center,
            //         children: [
            //           Image.asset('assets/inithome/right.png', width: 35,height: 35,),
            //           Column(
            //             crossAxisAlignment: CrossAxisAlignment.end,
            //             children: [
            //               Text('NewsPaper' , style: GoogleFonts.poppins(fontSize: 18 ,color: Color(0xff373737), fontWeight: FontWeight.w500),),
            //               Text('21 December 2023' , style: GoogleFonts.poppins(fontSize: 14 , color: Color(0xff8a8a8a) , fontWeight: FontWeight.w500),),
            //
            //             ],
            //           ),
            //         ],
            //       ),
            //     ),
            //   ),
            // ),
            // Padding(
            //   padding: const EdgeInsets.all(8.0),
            //   child: InkWell(
            //     onTap: (){
            //       Navigator.push(context,
            //           MaterialPageRoute(builder: (
            //               BuildContext context) => PickupConfirm(OrderDetails: {},))
            //       );
            //     },
            //     child: Card(
            //       elevation:1,
            //       child: Padding(
            //         padding: const EdgeInsets.all(20.0),
            //         child: Row(
            //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //           crossAxisAlignment: CrossAxisAlignment.center,
            //           children: [
            //             Icon(Icons.update , size: 40, color: Color(0xff039d00),),
            //             Column(
            //               crossAxisAlignment: CrossAxisAlignment.end,
            //               children: [
            //                 Text('NewsPaper' , style: GoogleFonts.poppins(fontSize: 18 ,color: Color(0xff373737), fontWeight: FontWeight.w500),),
            //                 Text('In progress' , style: GoogleFonts.poppins(fontSize: 14 , color: Color(0xff8a8a8a) , fontWeight: FontWeight.w500),),
            //
            //               ],
            //             ),
            //           ],
            //         ),
            //       ),
            //     ),
            //   ),
            // ),

          ],
        ),
      ),




    );
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar-15 ,bottom: 12),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Pickup requests' , style: GoogleFonts.lexend(fontSize: 18 , fontWeight: FontWeight.w500),),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Color(0xff00685C),
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30) , bottomRight: Radius.circular(30))
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}
