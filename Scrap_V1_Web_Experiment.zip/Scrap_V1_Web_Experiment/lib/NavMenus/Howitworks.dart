

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:scrap_app_v2/NavMenus/RequestStatus.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/screen3.dart';

class Howitworks extends StatefulWidget {
  const Howitworks({Key? key}) : super(key: key);

  @override
  State<Howitworks> createState() => _HowitworksState();
}

class _HowitworksState extends State<Howitworks> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: CustomAppBar(),
      body:
      SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            SizedBox(height: 125,),
            Padding(
              padding: const EdgeInsets.only(left: 25.0 , top: 20),
              child: Text('Sell your scrap in 4 Steps.' , style: GoogleFonts.lexend(fontSize: 20 ,fontWeight: FontWeight.w500)),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: Column(
                    children: [
                      Image.asset('assets/inithome/init1.png' , width: 150, height: 180,),
                    ],
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20.0 , top: 10 , right: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('1. Select scrap items for selling' , style: GoogleFonts.poppins(fontSize: 18 ,fontWeight: FontWeight.w500) , ),
                  SizedBox(height: 10,),
                  Text('We collect scrap from a wide variety of items such as newspapers, iron, large appliances, plastics, and machines. we do not pick up cloth or wood.' , style: GoogleFonts.poppins(fontSize: 13 ,color: const Color(0xFF8D8D8D) , fontWeight: FontWeight.normal) , ),
                ],
              ),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: Column(
                    children: [
                      Image.asset('assets/inithome/init2.png' , width: 150, height: 180,),
                    ],
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20.0 , top: 10 , right: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('2. Choose a date for scrap Pickup' , style: GoogleFonts.poppins(fontSize: 18 ,fontWeight: FontWeight.w500) , ),
                  SizedBox(height: 10,),
                  Text('Choose a data when you want our executives to come for scrap pickup. You can book a request for the next day. Our pickup time will be between 10 am to 6 pm.  ' , style: GoogleFonts.poppins(fontSize: 13 ,color: const Color(0xFF8D8D8D) , fontWeight: FontWeight.normal) , ),
                ],
              ),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: Column(
                    children: [
                      Image.asset('assets/inithome/init3.png' , width: 150, height: 180,),
                    ],
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20.0 , top: 10 , right: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('3. Pickup boys will arrive at your home' , style: GoogleFonts.poppins(fontSize: 18 ,fontWeight: FontWeight.w500) , ),
                  SizedBox(height: 10,),
                  Text('Our pickup executives will call you 1 hour before coming. They will bring an electric machine to weigh each scrap item separately.' , style: GoogleFonts.poppins(fontSize: 13 ,color: const Color(0xFF8D8D8D) , fontWeight: FontWeight.normal) , ),
                ],
              ),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: Column(
                    children: [
                      Image.asset('assets/inithome/init4.png' , width: 150, height: 180,),
                    ],
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20.0 , top: 10  ,right: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('4. Scrap sold :)' , style: GoogleFonts.poppins(fontSize: 18 ,fontWeight: FontWeight.w500) , ),
                  SizedBox(height: 10,),
                  Text('you will get a bill on your mobile and the amount will be transferred either by cash/UPI payments. The rates are non - negotiable. Please check the rates before booking a pickup request.' , style: GoogleFonts.poppins(fontSize: 13 ,color: const Color(0xFF8D8D8D) , fontWeight: FontWeight.normal) , ),
                ],
              ),
            ),
            SizedBox(height: 100,),
          ],
        ),
      ),



    );
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar-15 ,bottom: 12),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('How it Works?' , style: GoogleFonts.lexend(fontSize: 18 , fontWeight: FontWeight.w500),),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Color(0xff00685C),
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30) , bottomRight: Radius.circular(30))
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}
