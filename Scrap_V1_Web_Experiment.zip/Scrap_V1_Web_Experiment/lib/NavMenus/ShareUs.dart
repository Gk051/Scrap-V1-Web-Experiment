

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:scrap_app_v2/NavMenus/RequestStatus.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/screen3.dart';

class ShareUs extends StatefulWidget {
  const ShareUs({Key? key}) : super(key: key);

  @override
  State<ShareUs> createState() => _ShareUsState();
}

class _ShareUsState extends State<ShareUs> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: CustomAppBar(),
      body:
      SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 125,),

            Padding(
              padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 20),
              child: Text('Sell your scrap in 4 Steps.' , style: GoogleFonts.lexend(fontSize: 20 ,fontWeight: FontWeight.w500)),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 20),
              child: Text('Now sell your scrap easily from your doorsteps with the smart scrap. Download our app and raise a pickup request.' , style: GoogleFonts.poppins(fontSize: 13 ,color: Color(0xff8a8a8a))),
            ),

          ],
        ),
      ),
      floatingActionButton: SizedBox(
        width: double.infinity,
        child: Padding(
          padding: const EdgeInsets.only(left: 20, right: 20, top: 8),
          child: ElevatedButton(
            onPressed: () {
              // Action to be performed on button press
              // Navigator.push(context, MaterialPageRoute (
              //   builder: (BuildContext context) =>  PickAddress(),
              // ),);
            },
            style: ElevatedButton.styleFrom(
              foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
              elevation: 5, // Elevation (shadow)
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(3.0), // Rounded corners
              ),
              padding: EdgeInsets.symmetric(horizontal: 60, vertical: 11), // Button padding
            ),
            child: Text('Share Us' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w600),), // Button text
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,

    );
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar-15 ,bottom: 12),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Share Us' , style: GoogleFonts.lexend(fontSize: 18 , fontWeight: FontWeight.w500),),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Color(0xff00685C),
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30) , bottomRight: Radius.circular(30))
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}
