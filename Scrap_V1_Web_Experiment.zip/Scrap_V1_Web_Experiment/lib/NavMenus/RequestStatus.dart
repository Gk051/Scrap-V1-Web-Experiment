

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/screen3.dart';
import 'package:scrap_app_v2/Services/DataService.dart';
import 'package:scrap_app_v2/Services/ProviderService.dart';

import '../Pages/PickupScreens/PickupDetails.dart';

class PickStatus extends StatefulWidget {
  const PickStatus({Key? key , required this.OrderDetails}) : super(key: key);
  final Map<dynamic, dynamic> OrderDetails;
  @override
  State<PickStatus> createState() => _PickStatusState();
}

class _PickStatusState extends State<PickStatus> {
  late int OrderDetailsIndex;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print(widget.OrderDetails);
     }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: CustomAppBar(),
      body:
      SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            SizedBox(height: 125,),
            Padding(
              padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 25),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  context.watch<MainProvider>().Requests[context.watch<MainProvider>().Requests.indexOf(widget.OrderDetails)]['order_status']=="pending"?Icon(Icons.update , size: 70, color: Color(0xfffa9f0b),):context.watch<MainProvider>().Requests[context.watch<MainProvider>().Requests.indexOf(widget.OrderDetails)]['order_status']=="picked"?Image.asset('assets/inithome/right.png', width: 70,height: 70,):context.watch<MainProvider>().Requests[context.watch<MainProvider>().Requests.indexOf(widget.OrderDetails)]['order_status']=="accepted"?Icon(Icons.edit_calendar_rounded , size: 70, color: Colors.green,):Image.asset('assets/inithome/wrong.png', width: 70,height: 70,),

                  Text('Request \n${context.watch<MainProvider>().Requests[context.watch<MainProvider>().Requests.indexOf(widget.OrderDetails)]['order_status'].toString()}' , style: GoogleFonts.lexend(fontSize: 26 ,fontWeight: FontWeight.w500) , softWrap: true,maxLines: 2,),
                ],
              ),
            ),

            context.watch<MainProvider>().Requests[context.watch<MainProvider>().Requests.indexOf(widget.OrderDetails)]['order_status']=="cancelled"?Padding(
              padding: const EdgeInsets.all(5.0),
              child: Card(
                elevation:1,
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [

                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Cancellation reason' , style: GoogleFonts.poppins(fontSize: 13 , color: Color(0xff8a8a8a) , fontWeight: FontWeight.w500),),

                          Text(context.watch<MainProvider>().Requests[context.watch<MainProvider>().Requests.indexOf(widget.OrderDetails)]['cancellation_reason']??'I will be not available at the address.' , style: GoogleFonts.poppins(fontSize: 14 ,color: Color(0xff373737), fontWeight: FontWeight.w500),),

                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ):SizedBox(height: 5,),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Card(
                elevation:2,
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Pickup' , style: GoogleFonts.poppins(fontSize: 14 ,color: Color(0xff8a8a8a), fontWeight: FontWeight.w500),),
                          Text(DateFormat('dd MMMM yyyy').format(DateTime.parse(context.watch<MainProvider>().Requests[context.watch<MainProvider>().Requests.indexOf(widget.OrderDetails)]['pick_up_date'])) , style: GoogleFonts.poppins(fontSize: 12 , color: Color(0xff373737) , fontWeight: FontWeight.w500),),
                          Text('10 AM - 6 PM' , style: GoogleFonts.lexend(fontSize: 12 ,color: Color(0xff8a8a8a),),),

                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Request ID' , style: GoogleFonts.poppins(fontSize: 14 ,color: Color(0xff8a8a8a), fontWeight: FontWeight.w500),),
                          Text(context.watch<MainProvider>().Requests[context.watch<MainProvider>().Requests.indexOf(widget.OrderDetails)]['order_id'].substring(context.watch<MainProvider>().Requests[context.watch<MainProvider>().Requests.indexOf(widget.OrderDetails)]['order_id'].length - 4) , style: GoogleFonts.poppins(fontSize: 12 , color: Color(0xff373737) , fontWeight: FontWeight.w500),),

                        ],
                      ),
                       ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Card(
                elevation:2,
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(

                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Scrap items' , style: GoogleFonts.lexend(fontSize: 14 , color: Color(0xff8a8a8a)),),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Image.asset('assets/inithome/cat1.png'),
                            Text(context.watch<MainProvider>().Requests[context.watch<MainProvider>().Requests.indexOf(widget.OrderDetails)]['items'][0]['item_name'][0].toUpperCase() + context.watch<MainProvider>().Requests[context.watch<MainProvider>().Requests.indexOf(widget.OrderDetails)]['items'][0]['item_name'].substring(1) , style: GoogleFonts.poppins(fontSize: 14 , color: Color(0xff373737) , fontWeight: FontWeight.w500),),
                            Text('₹ ${context.watch<MainProvider>().Requests[context.watch<MainProvider>().Requests.indexOf(widget.OrderDetails)]['items'][0]['item_price']}.0/kg' , style: GoogleFonts.lexend(fontSize: 17),),


                          ],
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Card(
                elevation:2,
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Image.asset('assets/inithome/location.png'),
                      SizedBox(width: 10,),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Address' , style: GoogleFonts.poppins(fontSize: 14 ,color: Color(0xff8a8a8a), fontWeight: FontWeight.w500),),


                            Text(context.watch<MainProvider>().Requests[context.watch<MainProvider>().Requests.indexOf(widget.OrderDetails)]['address'] , style: GoogleFonts.poppins(fontSize: 12 , color: Color(0xff373737) , fontWeight: FontWeight.w500),maxLines: 2,overflow: TextOverflow.ellipsis,),

                          ],
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            ),

          ],
        ),
      ),
      floatingActionButton: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 0),
        child: Container(
          width: MediaQuery.of(context).size.width,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 0.0 , vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton(

                  onPressed: () {
                    // Action to be performed on button press
                    Navigator.push(context, MaterialPageRoute (
                        builder: (BuildContext context) =>  PickupDetails(OrderDetails: context.watch<MainProvider>().Requests[context.watch<MainProvider>().Requests.indexOf(widget.OrderDetails)],)),
                    );
                  },

                  style: ElevatedButton.styleFrom(
                    disabledBackgroundColor: Color(0xff00685c).withOpacity(0.4),
                    disabledForegroundColor: Colors.white,
                    foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
                    elevation: 5, // Elevation (shadow)
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(3.0), // Rounded corners
                    ),
                    padding: EdgeInsets.symmetric( vertical: 11 , horizontal: 10), // Button padding
                  ),
                  child: Text('Track Pickup Request' , style: GoogleFonts.poppins(fontSize: 16 , fontWeight: FontWeight.w600),), // Button text
                ),
                ElevatedButton(

                  onPressed: context.watch<MainProvider>().Requests[context.watch<MainProvider>().Requests.indexOf(widget.OrderDetails)]['order_status']=="cancelled"?null:() =>
                  _showCancellationDialog(context , context.read<MainProvider>().Requests[context.read<MainProvider>().Requests.indexOf(widget.OrderDetails)]['order_id'])
                  ,

                  style: ElevatedButton.styleFrom(
                    disabledBackgroundColor: Color(0xfffca311).withOpacity(0.4),
                    disabledForegroundColor: Colors.grey,
                    foregroundColor: Colors.black, backgroundColor: Color(0xfffca311), // Text color
                    elevation: 5, // Elevation (shadow)
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(3.0), // Rounded corners
                    ),
                    padding: EdgeInsets.symmetric( vertical: 11 , horizontal: 10), // Button padding
                  ),
                  child: Text('Cancel Order' , style: GoogleFonts.poppins(fontSize: 16 , fontWeight: FontWeight.w600),), // Button text
                ),
              ],
            ),
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,

    );
  }
  void _showCancellationDialog(BuildContext context , String OrderId) {
    String? selectedReason;
    bool showReasonField = false;
    final TextEditingController reasonController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              contentPadding: EdgeInsets.symmetric(horizontal: 0),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15)
              ),
              title:  Text('Tell us your reason for cancellation' , style: GoogleFonts.poppins(fontWeight: FontWeight.w500),),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    RadioListTile<String>(

                      title: Text('I will not be available at the address' , style: GoogleFonts.poppins(),),
                      value: 'Not available',
                      groupValue: selectedReason,
                      activeColor: Color(0xff184d47),
                      onChanged: (value) {
                        setState(() {
                          selectedReason = value;
                          showReasonField = false;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      title:  Text('Already sold to other vendor',style: GoogleFonts.poppins(),),
                      value: 'Sold to other vendor',
                      groupValue: selectedReason,
                      activeColor: Color(0xff184d47),
                      onChanged: (value) {
                        setState(() {
                          selectedReason = value;
                          showReasonField = false;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      title:  Text('Duplicate request by mistake',style: GoogleFonts.poppins(),),
                      value: 'Duplicate request',
                      groupValue: selectedReason,
                      activeColor: Color(0xff184d47),
                      onChanged: (value) {
                        setState(() {
                          selectedReason = value;
                          showReasonField = false;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      title:  Text('Pickup not on time',style: GoogleFonts.poppins(),),
                      value: 'Pickup not on time',
                      groupValue: selectedReason,
                      activeColor: Color(0xff184d47),
                      onChanged: (value) {
                        setState(() {
                          selectedReason = value;
                          showReasonField = false;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      title:  Text('No response from the executive',style: GoogleFonts.poppins(),),
                      value: 'No response',
                      activeColor: Color(0xff184d47),
                      groupValue: selectedReason,
                      onChanged: (value) {
                        setState(() {
                          selectedReason = value;
                          showReasonField = false;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      title:  Text('Rate issue',style: GoogleFonts.poppins(),),
                      value: 'Rate issue',
                      groupValue: selectedReason,
                      activeColor: Color(0xff184d47),
                      onChanged: (value) {
                        setState(() {
                          selectedReason = value;
                          showReasonField = false;
                        });
                      },
                    ),
                    RadioListTile<String>(
                      title:  Text('Other',style: GoogleFonts.poppins(),),
                      value: 'Other',
                      groupValue: selectedReason,
                      activeColor: Color(0xff184d47),
                      onChanged: (value) {
                        setState(() {
                          selectedReason = value;
                          showReasonField = true;
                        });
                      },
                    ),
                    if (showReasonField)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 15.0),
                        child: TextField(
                          controller: reasonController,
                          decoration:  InputDecoration(
                            focusedBorder: OutlineInputBorder(

                            ),
                            hintText: 'Please specify the reason',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                    const SizedBox(height: 10),
                    // const Text(
                    //   '1. Please take out scrap items for faster pickup.\n2. Show pickup code to our executive.',
                    //   style: TextStyle(fontSize: 12, color: Colors.grey),
                    // ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context); // Close the dialog
                  },
                  child: Text('Don\'t Cancel' , style: GoogleFonts.poppins(color: Color(0xff184d47),fontWeight: FontWeight.w600),),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      foregroundColor: Color(0xff184d47),
                      disabledForegroundColor: Colors.grey,
                      elevation: 0
                  ),

                  onPressed: selectedReason==null ?null:() async{
                    // Handle cancellation logic
                    final reason = selectedReason == 'Other'
                        ? reasonController.text
                        : selectedReason;
                    print('Cancellation Reason: $reason');
                    Response data = await Dataservice().CancelOrder(id: OrderId ,  reason: reason.toString());
                    if(data.statusCode == 200 || data.statusCode == 201){
                      var data = context.read<MainProvider>().Requests[context.read<MainProvider>().Requests.indexOf(widget.OrderDetails)];
                      context.read<MainProvider>().Requests[context.read<MainProvider>().Requests.indexOf(widget.OrderDetails)]['order_status'] = 'cancelled';
                      context.read<MainProvider>().Requests[context.read<MainProvider>().Requests.indexOf(widget.OrderDetails)]['cancellation_reason'] = reason.toString();
                      context.read<MainProvider>().Load();

                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Order Cancelled Successfully')));


                    }else{
                      Navigator.pop(context);

                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error Cancelling Order')));

                    }
                    // Close the dialog
                  },
                  child: Text('Cancel' , style: GoogleFonts.poppins(fontWeight: FontWeight.w600),),
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar-15 ,bottom: 12),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Pickup requests' , style: GoogleFonts.lexend(fontSize: 18 , fontWeight: FontWeight.w500),),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Color(0xff00685C),
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30) , bottomRight: Radius.circular(30))
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );

  }
}


// cancel popup


