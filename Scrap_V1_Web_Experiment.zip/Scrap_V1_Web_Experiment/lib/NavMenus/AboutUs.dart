

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:scrap_app_v2/NavMenus/RequestStatus.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/screen3.dart';

class AboutUs extends StatefulWidget {
  const AboutUs({Key? key}) : super(key: key);

  @override
  State<AboutUs> createState() => _AboutUsState();
}

class _AboutUsState extends State<AboutUs> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: CustomAppBar(),
      body:
      SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 125,),

            Padding(
              padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 25),
              child: Text('Welcome to Smart Scrap! We make selling your household scrap easy and rewarding. From newspapers to metals, we help you recycle and earn while contributing to a cleaner environment.' , style: GoogleFonts.lexend(fontSize: 15 ,color: Color(0xff8a8a8a))),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 25),
              child: Text('Why Choose Us' , style: GoogleFonts.lexend(fontSize: 15 ,color: Color(0xff000000) , fontWeight: FontWeight.w600)),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 25),
              child: Text('1. Convenient doorstep service \n\n2. Earn while recycling \n\n3. Top-notch technology for efficient processing \n\n4. Join us in responsible waste management' , style: GoogleFonts.lexend(fontSize: 15 ,color: Color(0xff8a8a8a) , )),
            ),

            SizedBox(height: 100,),
          ],
        ),
      ),



    );
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar-15 ,bottom: 12),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('About Us' , style: GoogleFonts.lexend(fontSize: 18 , fontWeight: FontWeight.w500),),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Color(0xff00685C),
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30) , bottomRight: Radius.circular(30))
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}
