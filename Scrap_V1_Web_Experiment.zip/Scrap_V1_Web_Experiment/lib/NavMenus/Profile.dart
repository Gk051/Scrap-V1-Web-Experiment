

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/NavMenus/MenuActions/UpdateEmail.dart';
import 'package:scrap_app_v2/NavMenus/MenuActions/UpdateMobile.dart';
import 'package:scrap_app_v2/NavMenus/MenuActions/UpdateName.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/AddAddress.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/pickAddress.dart';

import '../Pages/PickupScreens/PickMoneymode.dart';
import '../Services/ProviderService.dart';


class Profile extends StatefulWidget {
  const Profile({Key? key}) : super(key: key);

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  int _currentIndex = 0;
  String desc = '';
  TextEditingController myController1 = TextEditingController();
  void dispose() {
    // Clean up the controller when the widget is disposed.
    myController1.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: CustomAppBar(),
      body:
        SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 125,),

              Padding(
                padding: const EdgeInsets.only(left: 25.0 , top: 20),
                child: Row(
                  // mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Image.asset('assets/inithome/upload.png'),
                    SizedBox(width: 5,),
                    Expanded(
                      child: InkWell(onTap:(){
                        Navigator.push(context, MaterialPageRoute (
                          builder: (BuildContext context) =>  UpdateName(),
                        ),);
                      },child: Text(context.watch<MainProvider>().userData['user_name'] , style: GoogleFonts.lexend(fontSize: 20 ,fontWeight: FontWeight.w600), maxLines: 5,softWrap: true,)),
                    ),
                    TextButton(onPressed: (){
                      Navigator.push(context, MaterialPageRoute (
                        builder: (BuildContext context) =>  UpdateName(),
                      ),);
                    }, child: Text('Change' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500 , color: Color(0xff00685c)),))
                              
                  ],
                ),
              ),



              Padding(
                  padding: const EdgeInsets.only(left: 8.0 , top: 20 , right: 8  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                      children:[
                        Card(
                          elevation:2,
                          child: Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Mobile Number' , style: GoogleFonts.lexend(fontSize: 14 , color: Color(0xff8a8a8a) , fontWeight: FontWeight.w500),),

                                    Text(context.watch<MainProvider>().userData['mobile'].toString() , style: GoogleFonts.lexend(fontSize: 15 , fontWeight: FontWeight.w500),),

                                  ],
                                ),
                                TextButton(onPressed: (){
                                  Navigator.push(context, MaterialPageRoute (
                                    builder: (BuildContext context) =>  UpdateMobile(),
                                  ),);
                                }, child: Text('Change' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500 , color: Color(0xff00685c)),))
                              ],
                            ),
                          ),
                        ),
                        // Card(
                        //   elevation:2,
                        //   child: Padding(
                        //     padding: const EdgeInsets.all(20.0),
                        //     child: Row(
                        //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        //       crossAxisAlignment: CrossAxisAlignment.center,
                        //       children: [
                        //         Column(
                        //           crossAxisAlignment: CrossAxisAlignment.start,
                        //           children: [
                        //             Text('Email address' , style: GoogleFonts.lexend(fontSize: 14 , color: Color(0xff8a8a8a) , fontWeight: FontWeight.w500),),
                        //
                        //             Text('N/A' , style: GoogleFonts.lexend(fontSize: 15 , fontWeight: FontWeight.w500),),
                        //
                        //           ],
                        //         ),
                        //         TextButton(onPressed: (){
                        //           Navigator.push(context, MaterialPageRoute (
                        //             builder: (BuildContext context) =>  UpdateEmail(),
                        //           ),);
                        //         }, child: Text('Add' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500 , color: Color(0xff00685c)),))
                        //       ],
                        //     ),
                        //   ),
                        // ),
                        Padding(
                          padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 10 ),
                          child: Text('Pickup address' , style: GoogleFonts.poppins(fontSize: 13 , color: Color(0xff585858)),),
                        ),
                        Card(
                          elevation:2,
                          child: Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('Pickup Address - ${context.watch<MainProvider>().selectedAddressindex>=0 && context.watch<MainProvider>().Address.length>0?context.watch<MainProvider>().Address[context.watch<MainProvider>().selectedAddressindex]['type'] : 'Shop'}' , style: GoogleFonts.poppins(fontSize: 14 ,color: Color(0xff8a8a8a), fontWeight: FontWeight.w500),maxLines: 1,overflow: TextOverflow.ellipsis,),
                                      Text(context.watch<MainProvider>().Address.isNotEmpty && context.watch<MainProvider>().selectedAddressindex < context.watch<MainProvider>().Address.length ? context.watch<MainProvider>().Address[context.watch<MainProvider>().selectedAddressindex]['address'] ?? 'None' : 'None' , style: GoogleFonts.poppins(fontSize: 12 , color: Color(0xff373737) , fontWeight: FontWeight.w500),maxLines: 1,overflow: TextOverflow.ellipsis,),
                                  
                                    ],
                                  ),
                                ),
                                TextButton(onPressed: (){
                                  _showBottomModal(context);
                                  // Navigator.push(context, MaterialPageRoute (
                                  //   builder: (BuildContext context) =>  PickAddress(),
                                  // ),);
                                  // Navigator.push(context, MaterialPageRoute (
                                  //   builder: (BuildContext context) =>  AddAddress(),
                                  // ),);

                                }, child: Text('Change' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500 , color: Color(0xff00685c)),))
                              ],
                            ),
                          ),
                        ),

                        Card(
                          elevation:2,
                          child: Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Payment acceptence Method' , style: GoogleFonts.poppins(fontSize: 14 ,color: Color(0xff8a8a8a), fontWeight: FontWeight.w500),),
                                    Text(context.watch<MainProvider>().isCash?"Cash On Pickup":'UPI (${context.watch<MainProvider>().Upi})' , style: GoogleFonts.lexend(fontSize: 12  , fontWeight: FontWeight.w500),),

                                  ],
                                ),
                                TextButton(onPressed: (){
                                  Navigator.push(context, MaterialPageRoute (
                                    builder: (BuildContext context) =>  PickMoneyMode(),
                                  ),);
                                }, child: Text('Change' , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w500 , color: Color(0xff00685c)),))
                              ],
                            ),
                          ),
                        ),

                        SizedBox(height: 100,)
                      ]
                  )
              ),



            ],
          ),
        ),



    );
  }
}
void _showBottomModal(BuildContext context) {
  List<dynamic> addresses = context.read<MainProvider>().Address;
  // int selectedId = context.watch<MainProvider>().selectedAddressindex;
  showGeneralDialog(
    context: context,
    barrierLabel: "Barrier",
    barrierDismissible: true,
    barrierColor: Colors.black.withOpacity(0.5),
    transitionDuration: Duration(milliseconds: 500),
    pageBuilder: (_, __, ___) {
      return Align(
        alignment: Alignment.topCenter,
        child: Container(
          constraints: BoxConstraints(
              maxHeight: 540
          ),
          child: Material(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(top: 48.0 , left: 20 , right: 20 , bottom: 15),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Select Pickup\naddress' , style: GoogleFonts.lexend(fontSize: 26 , fontWeight: FontWeight.w600 , color: Color(0xff151111)),softWrap: true,),
                          Icon(Icons.keyboard_arrow_up , size: 50,)
                        ],
                      ),
                      // Padding(
                      //     padding: const EdgeInsets.only( top: 20 , ),
                      //     child: Container(
                      //       decoration: BoxDecoration(
                      //         border: Border.all(color: Color(0xff00685c) , width: 1),
                      //         borderRadius: BorderRadius.circular(3),
                      //         color: Color(0xffccebe8),
                      //       ),
                      //       width: double.infinity,
                      //       child: Padding(
                      //         padding: const EdgeInsets.all(15.0),
                      //         child: Row(
                      //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      //           crossAxisAlignment: CrossAxisAlignment.center,
                      //           children: [
                      //             Column(
                      //               crossAxisAlignment: CrossAxisAlignment.start,
                      //               children: [
                      //                 Text('Work' , style: GoogleFonts.poppins(fontSize: 15 , fontWeight: FontWeight.w500),),
                      //                 Text('12/5, opp to Govt-College , Palladam' , style: GoogleFonts.poppins(fontSize: 11 ),),
                      //
                      //               ],
                      //             ),
                      //
                      //           ],
                      //         ),
                      //       ),
                      //     )
                      // ),

                      SingleChildScrollView(
                        child: Container(
                          decoration: BoxDecoration(
                            // color: Colors.red
                          ),
                          constraints: BoxConstraints(
                              minHeight: 0,
                              maxHeight: 250
                          ),
                          child: ListView.builder(
                            itemCount: context.watch<MainProvider>().Address.length,
                            itemBuilder: (context, index) {
                              final address = context.read<MainProvider>().Address[index];
                              return Padding(
                                padding: const EdgeInsets.only( top: 20  ),
                                child:InkWell(
                                    onTap: (){


                                      context.read<MainProvider>().updateAddressIndex(index: index);

                                    },
                                    child:  Container(
                                      decoration: BoxDecoration(
                                        border: Border.all(color: context.watch<MainProvider>().selectedAddressindex == index ?Color(0xff00685c):Color(0xff8a8a8a) , width: 1),
                                        borderRadius: BorderRadius.circular(3),
                                        color: context.watch<MainProvider>().selectedAddressindex == index ?Color(0xffccebe8):Colors.transparent,
                                      ),
                                      width: double.infinity,
                                      child: Padding(
                                        padding: const EdgeInsets.all(12.0),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Expanded(
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Text(address['type'].toString() , style: GoogleFonts.poppins(fontSize: 16 , fontWeight: FontWeight.w500),),
                                                  Text(address['address'] , style: GoogleFonts.poppins(fontSize: 13 , fontWeight: FontWeight.w400 ),overflow: TextOverflow.ellipsis,maxLines: 1,),

                                                ],
                                              ),
                                            ),
                                            // IconButton(onPressed: (){}, icon: Icon(Icons.delete , size: 30 , color: Color(0xff00685c),))
                                          ],
                                        ),
                                      ),
                                    )
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: 1,
                              width: 100,
                              color: Color(0xff8a8a8a),
                            ),
                            SizedBox(width: 10,),
                            Text('OR' , style: GoogleFonts.lexend(fontSize: 10,),),
                            SizedBox(width: 10,),
                            Container(
                              height: 1,
                              width: 100,
                              color: Color(0xff8a8a8a),
                            ),
                          ],
                        ),
                      ),
                      TextButton(
                        onPressed: (){
                          Navigator.push(context, MaterialPageRoute (
                            builder: (BuildContext context) =>  AddAddress(),
                          ),);
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.add_circle_outline , size: 25, color: Color(0xff00685c),),
                            SizedBox(width: 10,),
                            Text('Add Address' , style: GoogleFonts.poppins(fontSize: 15 , color: Color(0xff00685c),fontWeight: FontWeight.w600)),
                          ],
                        ),
                      )
                    ],
                  ),
                ),

              ],
            ),
          ),
          margin: EdgeInsets.only(bottom: 0, left: 0, right: 0),
        ),
      );
    },
    transitionBuilder: (_, anim, __, child) {
      return SlideTransition(
        position: Tween(begin: Offset(0, -1), end: Offset(0, 0))
            .animate(anim),
        child: child,
      );
    },
  );
}
class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar-15 ,bottom: 12),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Profile' , style: GoogleFonts.lexend(fontSize: 18 , fontWeight: FontWeight.w500),),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Color(0xff00685C),
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30) , bottomRight: Radius.circular(30))
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}
