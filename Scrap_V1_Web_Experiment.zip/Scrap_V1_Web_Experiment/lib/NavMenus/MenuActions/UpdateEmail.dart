

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:scrap_app_v2/Pages/PickupScreens/pickAddress.dart';


class UpdateEmail extends StatefulWidget {
  const UpdateEmail({Key? key}) : super(key: key);

  @override
  State<UpdateEmail> createState() => _UpdateEmailState();
}

class _UpdateEmailState extends State<UpdateEmail> {
  int _currentIndex = 0;
  String desc = '';
  TextEditingController myController1 = TextEditingController();
  void dispose() {
    // Clean up the controller when the widget is disposed.
    myController1.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: CustomAppBar(),
      body:
        SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 125,),
              Padding(
                padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 10 ),
                child: Image.asset('assets/inithome/ep.png'),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 25.0 , top: 20),
                child: Text('Type your Email' , style: GoogleFonts.montserrat(fontSize: 26,color: Color(0xff00685c) ,fontWeight: FontWeight.w500)),
              ),



              Padding(
                  padding: const EdgeInsets.only(left: 25.0 , top: 20 , right: 25  ),
                  child: TextFormField(
                    maxLines: 1,
                    controller: myController1,
                    decoration:  InputDecoration(
                      // filled:true,

                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Color(0xffa8a8a8),
                            width: 1.8,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          // borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(
                            color: Color(0xff00685c),
                            width: 1.4,
                          ),
                        ),
                        labelStyle: TextStyle(
                            color: Color(0xffa8a8a8),
                            fontSize: 10

                        ),

                        hoverColor: Color(0xff00685c)
                    ),
                    keyboardType: TextInputType.number,
                    onFieldSubmitted: (value) {
                      setState(() {
                        desc = value;
                      });
                    },
                    validator: (value) {
                      if (value!.isEmpty ) {
                        return 'Invalid desc!';
                      }
                      return null;
                    },
                  ),
              ),


            ],
          ),
        ),
      floatingActionButton: ElevatedButton(
        onPressed: () {
          // Action to be performed on button press
          Navigator.push(context, MaterialPageRoute (
            builder: (BuildContext context) =>  PickAddress(),
          ),);
        },
        style: ElevatedButton.styleFrom(
          foregroundColor: Colors.white, backgroundColor: Color(0xff00685c), // Text color
          elevation: 5, // Elevation (shadow)
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(3.0), // Rounded corners
          ),
          padding: EdgeInsets.symmetric(horizontal: 60, vertical: 11), // Button padding
        ),
        child: Text('Update' , style: GoogleFonts.poppins(fontSize: 18 , fontWeight: FontWeight.w600),), // Button text
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,

    );
  }
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {

  @override
  Size get preferredSize => Size.fromHeight(100);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xff184d47), // Change this to the desired color
      ),
    );
    double statusbar = MediaQuery.of(context).padding.top;
    return Padding(
      padding: EdgeInsets.only(top: statusbar-15 ,bottom: 5),
      child: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Image.asset('assets/inithome/listicon.png'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Edit Profile' , style: GoogleFonts.lexend(fontSize: 18 , fontWeight: FontWeight.w500),),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Colors.white12,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(40.0), // Adjust the radius as needed
            ),
            image: DecorationImage(
              image: AssetImage('assets/inithome/appbar-img.png'), // Replace with your image asset
              fit: BoxFit.contain,
            ),
          ),
        ),
      ),
    );
  }
}
