import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/gestures.dart' show PointerDeviceKind;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:scrap_app_v2/Components/ResponsiveShell.dart';
import 'package:scrap_app_v2/Pages/Authenticate/Authenticate.dart';
import 'package:scrap_app_v2/Pages/MainHome.dart';
import 'package:scrap_app_v2/Services/ProviderService.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'Services/LoaderService.dart';

void main() {
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  // WEB EXPERIMENT: the native splash only exists on Android/iOS. On the web it
  // is skipped so it can never be left "preserved" (a stuck splash).
  if (!kIsWeb) {
    FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);
  }
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => MainProvider()),
        ChangeNotifierProvider(create: (_) => LoaderProvider()),
      ],
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(

        title: 'Scrap App',
        theme: ThemeData(
            fontFamily: 'Montserrat',
          appBarTheme: AppBarTheme(
            foregroundColor: Colors.white,

          ),

        ),
        // WEB EXPERIMENT: responsive page shell + mouse/trackpad drag scrolling
        builder: (context, child) =>
            ResponsiveShell(child: child ?? const SizedBox.shrink()),
        scrollBehavior: const MaterialScrollBehavior().copyWith(
          dragDevices: {
            PointerDeviceKind.touch,
            PointerDeviceKind.mouse,
            PointerDeviceKind.stylus,
            PointerDeviceKind.trackpad,
          },
        ),
        initialRoute: '/home',
        debugShowCheckedModeBanner: false,
        routes: <String, WidgetBuilder>{
          "/home": (BuildContext context) =>  MainHome(),
        });

  }
}
