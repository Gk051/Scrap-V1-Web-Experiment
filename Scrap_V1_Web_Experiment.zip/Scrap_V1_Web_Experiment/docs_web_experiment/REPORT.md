# Scrap V1 – Web Experiment: Report

**Status: EXPERIMENT – NOT TESTED, NOT PRODUCTION-READY.**
Code changes were written and checked for syntax only. They have **not been compiled, run or tested in a browser**, and the backend was unreachable, so no end-to-end test was possible. See section 5.

The original project (`scrap_app_v2.zip`) was not modified. All work is in this copy, `Scrap_V1_Web_Experiment`.
The copy is identical to the original except for the files listed in section 3. The Android signing key, `key.properties` and `local.properties` were **left out** of this copy on purpose (a web build does not need them).

---

## 1. Why the app hangs on the loading screen

| Item | Status |
|---|---|
| The code turns a spinner on, calls the API, and only turns it off if the call succeeds. Any failed call (no connection, timeout, unexpected reply) leaves the spinner on forever. No request had a timeout. | **CONFIRMED in the code** (login, signup, home, product list, requests, rate list, order confirmation) |
| The API host `sachitbsha.pythonanywhere.com` currently shows PythonAnywhere's "Coming Soon" page instead of API data (screenshot supplied by the product manager). The app cannot read that page as data and fails. | **CONFIRMED by screenshot.** Not independently re-verified (the build environment cannot reach the host). |
| The spinner on a phone is the result of the two points above. | **Strongly supported, not observed on a device.** Needs a device log or screenshot of which spinner is showing. |
| A saved `user_id` from an earlier login makes the app skip the login form and go straight to the home screen, which then fails to load. | HYPOTHESIS (consistent with the code) |
| `http://` (not `https://`) base URL: Android may block it, and a web page served over HTTPS cannot call it. | Code fact confirmed; Android behaviour is a hypothesis. |

## 2. What was audited (summary)

* **Architecture:** Flutter app, state via `provider` (`MainProvider`, `LoaderProvider`). Entry `lib/main.dart` → `MainHome` → first-run intro screens or `Authenticate` (login/sign-up bottom sheets) → `CategoryHome` (tabs: Sell Scrap / Rate List, side menu). Pickup flow: `screen1` (items) → `screen2` → `screen3` (book order) → `PickupConfirm`; also address, payment mode and UPI screens. Navigation uses plain `Navigator.push` (no named routes), so a browser refresh restarts at the launch screen.
* **Auth:** only a numeric `user_id` is stored (`flutter_secure_storage`, key `user_id`). There is **no token**; "session expiry" does not exist in this design.
* **API calls (unchanged):** `POST api/login/`, `api/register/`, `api/forgot-password`, `api/reset-password`, `api/logout/`, `api/fetch_profile_details/`, `api/update_profile/`, `api/add_new_address/`, `api/book_order/`, `api/fetch_order_details/`, `api/cancel_order/`, `api/get_order_details_for_user/`; `GET api/get_categories/`, `api/fetch_products_for_category/?category_id=`, `api/fetch_rate_list/`.
* **Web compatibility:**
  * No camera, image upload, file picker or location features exist in the app, so those do not apply.
  * `flutter_secure_storage` 8.1.0, `shared_preferences`, `url_launcher`, `fluttertoast`, `lottie`, `permission_handler` all have web implementations in the lock file. On the web, secure storage keeps an encrypted value in the browser's own storage: it needs HTTPS (or localhost) and is cleared when the user clears site data.
  * `permission_handler` phone permission does not exist in browsers (Call Us button) – fixed.
  * `flutter_native_splash` is Android/iOS only – skipped on web.
  * `google_fonts` (Poppins, Lexend) and `fluttertoast` load resources from the internet at run time.
  * **The project had no `web/index.html` and an empty `web/manifest.json`**, so no web build was possible – added.
* **Not reviewed line by line:** `screen2`, `pickAddress`, `AddAddress`, `EditUPI`, `PickMoneymode`, `PickupDetails`, `forgotPassword` dialog layout, About/How-it-works pages. They use the same fixed-size layout style as the rest of the app and need visual checking in a browser.

## 3. Every change made (copy only)

A full machine-readable diff against the original is in `docs_web_experiment/changes.patch`.

| File | Change | Why |
|---|---|---|
| `web/index.html` (new) | Standard Flutter web page with viewport tag and a small loading indicator | Required for any web build |
| `web/manifest.json` | Filled in (was empty) | Required for install/“add to home screen” and valid web build |
| `lib/Constants/globals.dart` | API base URL can be set at build time (`--dart-define=API_BASE_URL=...`). Default is the same host as before but `https://`. Original values kept in comments. | A page on HTTPS cannot call `http://`; lets you point at the correct host without code changes |
| `lib/Services/http_with_timeout.dart` (new) | Same `get`/`post` signatures as `package:http`, with a 20-second timeout, plus `friendlyError()` for user-safe messages | No request can wait forever |
| `lib/Services/AuthenticateService.dart`, `DataService.dart`, `Components/Navbar.dart` | Import the wrapper instead of `package:http` (calls themselves unchanged). `ResetPassword`/`VerifyOTP` return `false` on network errors. `GetProducts` and `GetAllOrderDetails` no longer swallow errors (their only callers now handle them). | Timeouts; errors reach the screens |
| `lib/Services/SecureStorageServices.dart` | All reads/writes tolerate failure; unreadable value is cleared and treated as "not signed in" | A storage error used to leave the launch screen spinning |
| `lib/Pages/MainHome.dart` | Failure-tolerant first-run check; placeholder splash no longer builds a second `Authenticate()`; splash removal skipped on web | Removes a duplicate login check and a possible web crash |
| `lib/main.dart` | Skip native splash on web; add responsive page shell; mouse/trackpad drag scrolling | Web support |
| `lib/Pages/Authenticate/Authenticate.dart` | Stored-session check wrapped; invalid id cleared; stale loader reset; `mounted` checks | Cannot hang on storage errors |
| `lib/Pages/Authenticate/login.dart` | `try/catch` around sign-in; loader always cleared; messages for server problems vs wrong credentials; sheet scrolls on short screens; removed unused `dart:io` | Cannot spin forever; keyboard-safe. Same request and same success rule (`code == 200`, `user_id`). |
| `lib/Pages/Authenticate/signup.dart` | Same pattern; password field is also required before submitting; if auto sign-in after sign-up fails, user is told to sign in | Same |
| `lib/Pages/CategoryHome.dart`, `Pickup/screen1.dart`, `Pickup/PickupConfirm.dart`, `NavMenus/Requests.dart`, `Ratelist/RateList.dart`, `Ratelist/MainRateList.dart` | Load wrapped in `try/catch`; loader always cleared; error message with **Try again** button; invalid data shapes handled | The core "stuck loader" fix |
| `lib/Components/LoadingOrError.dart` (new) | Spinner or error + retry button | Shared UI for the above |
| `lib/Components/ResponsiveShell.dart` (new) | Phones: full width as before. Wider screens: centred column (max 560 px) on a soft background; text scale limited to 0.8–1.3 | Stops the phone layout stretching on tablets/desktops |
| `lib/Components/Navbar.dart` | Call Us skips the phone permission on web; Logout always clears the saved session even if the server cannot be reached | Web compatibility; sign-out reliability |
| `.github/workflows/build-web.yml` (new) | Manual-only cloud build that produces a downloadable web build. **Does not deploy.** | You have no local Flutter |

**Not changed:** backend, database, API endpoints, request/response formats, authentication behaviour, `pubspec.yaml`/dependencies, Android/iOS projects.

**Behaviour differences to be aware of (all in the copy only):** the default API address is `https://` instead of `http://`; sign-up requires a password; error messages appear where the app used to spin or crash.

## 4. Backend / hosting changes required (NOT implemented)

1. **Redeploy or fix the backend (blocking).** `https://sachitbsha.pythonanywhere.com/api/get_categories/` returns PythonAnywhere's default page. In PythonAnywhere → **Web** tab: confirm a web app exists for the domain, is enabled and **Reloaded**, then read the error log. If the real backend lives under another account (`sachituk`, `Udhay` appear in the original code), tell us the correct address and use it as `API_BASE_URL`.
2. **HTTPS** with a valid certificate on the API host (PythonAnywhere provides this for `*.pythonanywhere.com`).
3. **CORS (required for any browser app).** The API must answer browser "preflight" (`OPTIONS`) requests and send `Access-Control-Allow-Origin` for the exact web address you deploy to, allow methods `GET, POST, OPTIONS` and header `Content-Type`. (For Django: `django-cors-headers`, `CORS_ALLOWED_ORIGINS = ["https://<your-web-url>"]`.) The app does not use cookies, so credentials are not needed.
4. **Trailing slashes:** `api/forgot-password` and `api/reset-password` are called without a trailing slash while other routes have one. Make sure both forms work for POST (a redirect would break them).
5. **Consistent JSON errors:** return JSON (with proper status codes) for errors instead of HTML pages, so the app can distinguish "wrong password" from "server error".
6. **Authentication design (security recommendation, not implemented):** the API identifies users only by a `user_id` sent by the client and issues no token. On the web, anyone can call the API from any browser, so each endpoint must verify the caller is allowed to access that `user_id`. Consider token-based sessions in a future version; that would change the API contract and needs approval.

## 5. Test report

Legend: PASS = actually run and passed; FAIL = run and failed; BLOCKED = could not run; NOT RUN = not attempted.

| Test | Result | Note |
|---|---|---|
| Original project unchanged (SHA-256 of all 202 files before/after) | **PASS** | |
| Working copy identical to original except listed changes (diff) | **PASS** | |
| Dart syntax check of all 42 Dart files | **PASS** | Syntax only (tree-sitter parser), not a compiler |
| All 343 imports resolve to a project file or declared dependency | **PASS** | |
| `web/manifest.json` is valid JSON | **PASS** | |
| Resolve dependencies (`flutter pub get`) | **BLOCKED** | `pub.dev` and Flutter downloads are not reachable from the build environment |
| Static analysis (`flutter analyze`) | **BLOCKED** | Same reason. **Type errors are possible and unchecked.** |
| Existing automated tests | **NOT RUN** | The project contains no tests |
| `flutter build web --release` | **BLOCKED** | Same reason. **No web build output was produced.** |
| Layout at mobile / tablet / desktop, portrait & landscape, browser zoom | **NOT RUN** | Needs a build |
| Routes, navigation, back button, refresh, session restore | **NOT RUN** | Needs a build |
| Login, registration, password recovery, booking against the real API | **BLOCKED** | Needs a build **and** a working backend |
| Console errors, failed requests, CORS | **BLOCKED** | Needs a build, hosted URL and working backend |
| Backend: `GET /api/get_categories/` over HTTPS | **FAIL** | Reported by the product manager: returns PythonAnywhere "Coming Soon". Not re-checked here (host unreachable from build environment). |
| File upload / camera / location | **N/A** | App has none of these features |

**Known limits of the responsive work:** the app is not yet a true multi-column tablet/desktop design – wide screens get a centred phone-style column. Fixed pixel heights remain (e.g. the 125 px spacing under the transparent app bar, the 500 px address-list height) and may clip on short landscape phones. These need to be checked in a browser before further layout work.

## 6. How to get a web build and a URL (no programming)

You need a free GitHub account and a free static-hosting account (Netlify is used below). The backend must be working first (section 4), otherwise the web app will load but show "We could not reach the server".

**A. Build in the cloud**
1. Create a **private** GitHub repository and upload everything from this project folder (make sure the hidden `.github/workflows/build-web.yml` file is included; if not, use *Add file → Create new file*, name it `.github/workflows/build-web.yml` and paste its contents).
2. Open the repo's **Actions** tab → **Build Scrap web (manual)** → **Run workflow**.
3. Enter the API address (must start with `https://` and end with `/`, e.g. `https://your-api-host/`) and keep Base href as `/`. Click **Run workflow**.
4. Wait about 5–10 minutes. If it fails, open the failed step and send me the red error text – I can fix compile problems then (this is the first time the code is compiled).
5. When it finishes, download the **scrap-web-build** file at the bottom of the run page and unzip it. The folder contains `index.html`.

**B. Put it online**
1. Go to Netlify's "Drop" page (app.netlify.com/drop), sign in, and drag the unzipped folder in. You immediately get an HTTPS address such as `https://something.netlify.app`.
2. Give that address to the backend developer so they add it to the CORS list (section 4.3).

The app uses `#` addresses (e.g. `site.com/#/home`), so refreshing the page works on any static host without extra settings.

**C. Test on different devices**
1. Open the address on an Android phone, an iPhone, a tablet and a laptop (Chrome and Safari).
2. Check: first load, sign up, sign in, close and reopen (stays signed in), browse categories, book a pickup, rate list, sign out.
3. Rotate the device and zoom the browser (Ctrl +/–). Note anything clipped or overlapping with a screenshot and the device name.
4. If something fails on a laptop: press F12 → **Console** and **Network** tabs → screenshot red errors (these show CORS or server problems).
5. After you upload a new build, hard-refresh (Ctrl+Shift+R) because browsers cache the app.

## 7. Next steps

1. Fix the backend (section 4, items 1–3). Without it nothing can be tested end to end.
2. Run the cloud build (section 6A) and send me any compile errors.
3. Test on devices; send screenshots of layout problems.
4. Then build real tablet/desktop layouts screen by screen (list first: login sheet, category grid, product list, booking forms).
